<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pesanan & Pembayaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

    <style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        background: #f4f4f4;
        padding: 20px;
        font-family: system-ui, -apple-system, sans-serif;
    }

    .card {
        background: #ffffff;
        border-radius: 12px;
        border: 0.5px solid #e0e0e0;
        overflow: hidden;
        max-width: 760px;
        margin: 0 auto;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .card-header {
        background: #4CAF50;
        color: white;
        padding: 14px 20px;
        font-size: 15px;
        font-weight: 500;
        text-align: center;
    }

    table.order-table {
        width: 100%;
        border-collapse: collapse;
    }

    table.order-table th {
        background: #f8f9fa;
        padding: 10px 16px;
        font-size: 13px;
        font-weight: 500;
        color: #6c757d;
        text-align: left;
        border-bottom: 0.5px solid #e0e0e0;
    }

    table.order-table td {
        padding: 12px 16px;
        font-size: 14px;
        border-bottom: 0.5px solid #e0e0e0;
    }

    .total-row td {
        background: #e8f5e9;
        font-weight: 500;
        color: #2e7d32;
    }

    .payment-section {
        padding: 20px;
        border-top: 0.5px solid #e0e0e0;
        text-align: center;
    }

    .payment-title {
        font-size: 14px;
        font-weight: 500;
        color: #212529;
        margin-bottom: 14px;
    }

    .notice {
        font-size: 12px;
        color: #6c757d;
        margin-top: 12px;
        display: flex;
        gap: 6px;
        align-items: center;
        justify-content: center;
    }

    .notice i {
        color: #F59E0B;
        font-size: 14px;
    }

    .footer-btns {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        border-top: 0.5px solid #e0e0e0;
        background: #fff;
    }

    .btn-back {
        padding: 9px 18px;
        border-radius: 8px;
        border: 0.5px solid #ced4da;
        background: #607D8B;
        color: white;
        font-size: 13px;
        cursor: pointer;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .btn-pay {
        padding: 10px 28px;
        border-radius: 8px;
        border: none;
        background: #4CAF50;
        color: white;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .btn-pay:disabled {
        background: #9E9E9E;
        cursor: not-allowed;
    }
    </style>
</head>

<body>

    <div class="card">
        <div class="card-header">Konfirmasi Pesanan & Pembayaran</div>

        <table class="order-table">
            <thead>
                <tr>
                    <th style="width:40px">No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th style="text-align:center;">Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                @foreach($pesanan->detailPesanan as $index => $detail)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $detail->nama_produk }}</td>
                    <td>Rp {{ number_format($detail->harga, 0, ',', '.') }}</td>
                    <td style="text-align:center;">{{ $detail->jumlah }}</td>
                    <td>Rp {{ number_format($detail->subtotal, 0, ',', '.') }}</td>
                </tr>
                @endforeach
                <tr class="total-row">
                    <td colspan="4" style="text-align: right; font-weight: bold;">TOTAL:</td>
                    <td style="font-weight: bold;">Rp {{ number_format($pesanan->total_harga, 0, ',', '.') }}</td>
                </tr>
            </tbody>
        </table>

        <div class="payment-section">
            <div class="payment-title">
                <i class="ti ti-credit-card" style="font-size:15px;vertical-align:-2px;margin-right:6px"
                    aria-hidden="true"></i>
                Klik tombol di bawah untuk memilih metode pembayaran
            </div>

            <button type="button" class="btn-pay" id="pay-button">
                <i class="ti ti-check" aria-hidden="true"></i> Bayar Sekarang
            </button>

            <div class="notice">
                <i class="ti ti-alert-triangle" aria-hidden="true"></i>
                Kamu akan diarahkan ke halaman pembayaran resmi Midtrans (Virtual Account, e-wallet, dll).
            </div>
        </div>

        <div class="footer-btns">
            <a href="{{ url('customer/riwayat-belanja') }}" class="btn-back">
                <i class="ti ti-arrow-left" aria-hidden="true"></i> Kembali
            </a>
        </div>
    </div>

    <!-- Snap.js dari Midtrans -->
    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrans.client_key') }}">
    </script>

    <script>
    const payBtn = document.getElementById('pay-button');
    const snapToken = @json($snapToken);

    payBtn.addEventListener('click', function () {
        if (!snapToken) { alert('Token pembayaran kosong. Coba refresh halaman.'); return; }
        payBtn.disabled = true;
        payBtn.innerHTML = 'Memuat...';
        window.location.href = 'https://app.sandbox.midtrans.com/snap/v2/vtweb/' + snapToken;
    });
</script>
</body>

</html>
