@extends('v_layouts.app')

@section('judul', 'Riwayat Belanja')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
.riwayat-wrapper {
    max-width: 1100px;
    margin: 0 auto;
}

.riwayat-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.riwayat-header h4 {
    margin: 0;
    font-weight: 700;
    color: #1e2a3a;
    font-size: 20px;
}

.riwayat-header .icon-wrap {
    background: #1976d2;
    color: #fff;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

/* ── TABEL HISTORY ── */
.history-table-wrap {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.07);
    overflow: hidden;
    border: 1px solid #e8eaf0;
}

.history-table-scroll {
    max-height: 70vh;
    overflow-y: auto;
    overflow-x: auto;
}

.history-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.history-table thead tr {
    background: #f5f7fa;
    border-bottom: 2px solid #e8eaf0;
}

.history-table thead th {
    padding: 12px 16px;
    color: #444;
    font-weight: 700;
    text-align: left;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.04em;
}

.history-table tbody td {
    padding: 12px 16px;
    border-bottom: 1px solid #f0f0f0;
    color: #444;
    vertical-align: middle;
}

.history-table tbody tr:last-child td {
    border-bottom: none;
}

.history-table tbody tr:hover td {
    background: #fafbff;
}

.kode-pesanan-link {
    font-weight: 700;
    color: #1976d2;
    text-decoration: none;
}

.kode-pesanan-link:hover {
    text-decoration: underline;
    color: #1251a3;
}

.total-bayar {
    font-weight: 700;
    color: #1e2a3a;
}

.detail-actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.btn-aksi {
    border: none;
    border-radius: 6px;
    padding: 6px 12px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: #fff;
    white-space: nowrap;
}

.btn-lihat-detail {
    background: #1976d2;
}

.btn-lihat-detail:hover {
    background: #1251a3;
    color: #fff;
}

.btn-invoice {
    background: #495057;
}

.btn-invoice:hover {
    background: #343a40;
    color: #fff;
}

.btn-lacak-sm {
    background: #28a745;
}

.btn-lacak-sm:hover {
    background: #1e7e34;
    color: #fff;
}

.btn-bayar-sm {
    background: #f59e0b;
}

.btn-bayar-sm:hover {
    background: #d18306;
    color: #fff;
}

/* ── ROW DETAIL (expand) ── */
.row-detail td {
    background: #fafbfc;
    padding: 0 !important;
}

.detail-inner {
    padding: 14px 20px;
}

.mini-detail-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}

.mini-detail-table thead th {
    padding: 6px 10px;
    background: #f0f4ff;
    color: #444;
    font-weight: 600;
    text-align: left;
    border-bottom: 1px solid #dde3f0;
}

.mini-detail-table tbody td {
    padding: 6px 10px;
    border-bottom: 1px solid #f0f0f0;
    color: #555;
}

.mini-detail-table tbody tr:last-child td {
    border-bottom: none;
}

/* ── STATUS BADGE ── */
.status-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: capitalize;
}

.status-pending,
.status-menunggu-pembayaran {
    background: #fff3cd;
    color: #856404;
}

.status-proses {
    background: #cce5ff;
    color: #004085;
}

.status-dikirim {
    background: #d4edda;
    color: #155724;
}

.status-selesai {
    background: #d1ecf1;
    color: #0c5460;
}

.status-dibatalkan {
    background: #f8d7da;
    color: #721c24;
}

.status-default {
    background: #e2e3e5;
    color: #383d41;
}

/* ── KOSONG ── */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: #aaa;
}

.empty-state i {
    font-size: 56px;
    margin-bottom: 16px;
    display: block;
    color: #ddd;
}

.empty-state p {
    font-size: 15px;
    margin-bottom: 16px;
}

/* ── MODAL TRACKING (tetap dipakai, tidak diubah) ── */
.modal-tracking .modal-dialog {
    max-width: 560px;
}

.modal-tracking .modal-header {
    background: #1976d2;
    color: #fff;
    border-radius: 12px 12px 0 0;
    padding: 14px 20px;
}

.modal-tracking .modal-header .modal-title {
    font-weight: 700;
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.modal-tracking .modal-header .close {
    color: #fff;
    opacity: 0.8;
    font-size: 22px;
}

.modal-tracking .modal-header .close:hover {
    opacity: 1;
}

.ekspedisi-info-box {
    background: #f0f7ff;
    border: 1px solid #c3d9f7;
    border-radius: 10px;
    padding: 14px 16px;
    margin-bottom: 18px;
    display: flex;
    align-items: flex-start;
    gap: 14px;
}

.ekspedisi-logo-box {
    width: 52px;
    height: 52px;
    border-radius: 8px;
    background: #fff;
    border: 1px solid #dde8f8;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 700;
    color: #1976d2;
    text-align: center;
    line-height: 1.3;
    flex-shrink: 0;
}

.ekspedisi-detail {
    flex: 1;
}

.ekspedisi-nama {
    font-size: 15px;
    font-weight: 700;
    color: #1e2a3a;
    margin-bottom: 2px;
}

.ekspedisi-layanan {
    font-size: 12px;
    color: #666;
    margin-bottom: 8px;
}

.resi-row {
    background: #fff;
    border: 1px solid #dde8f8;
    border-radius: 6px;
    padding: 7px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.resi-label-sm {
    font-size: 11px;
    color: #888;
}

.resi-value {
    font-family: monospace;
    font-size: 14px;
    font-weight: 700;
    color: #1e2a3a;
    letter-spacing: 1px;
}

.resi-copy-btn {
    background: none;
    border: none;
    color: #1976d2;
    font-size: 12px;
    cursor: pointer;
    padding: 0;
    display: flex;
    align-items: center;
    gap: 3px;
    white-space: nowrap;
}

.resi-copy-btn:hover {
    text-decoration: underline;
}

.lokasi-box {
    background: #f0fff4;
    border: 1px solid #b7e4c7;
    border-left: 4px solid #28a745;
    border-radius: 8px;
    padding: 12px 14px;
    margin-bottom: 18px;
}

.lokasi-box .lokasi-title {
    font-size: 11px;
    color: #28a745;
    font-weight: 600;
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 5px;
}

.lokasi-box .lokasi-nama {
    font-size: 14px;
    font-weight: 700;
    color: #1e2a3a;
    margin-bottom: 2px;
}

.lokasi-box .lokasi-alamat {
    font-size: 12px;
    color: #555;
    margin-bottom: 8px;
}

.lokasi-box .eta-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 8px;
    border-top: 1px solid #c3e6cb;
}

.eta-label-sm {
    font-size: 12px;
    color: #666;
}

.eta-value {
    font-size: 13px;
    font-weight: 700;
    color: #155724;
}

.tracking-section-title {
    font-size: 11px;
    font-weight: 700;
    color: #888;
    letter-spacing: 0.07em;
    text-transform: uppercase;
    margin-bottom: 12px;
}

.timeline-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.timeline-list li {
    display: flex;
    gap: 14px;
    padding-bottom: 18px;
    position: relative;
}

.timeline-list li:last-child {
    padding-bottom: 0;
}

.timeline-list li:not(:last-child) .tl-icon-wrap::after {
    content: '';
    position: absolute;
    left: 15px;
    top: 32px;
    width: 1px;
    height: calc(100% - 14px);
    background: #d0dce8;
}

.tl-icon-wrap {
    position: relative;
    flex-shrink: 0;
}

.tl-icon {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
}

.tl-icon.current {
    background: #1976d2;
    color: #fff;
}

.tl-icon.done {
    background: #e8f5e9;
    color: #28a745;
    border: 1px solid #b7e4c7;
}

.tl-icon.pending {
    background: #f5f5f5;
    color: #bbb;
    border: 1px solid #e0e0e0;
}

.tl-content {
    flex: 1;
    padding-top: 4px;
}

.tl-event {
    font-size: 13px;
    font-weight: 600;
    color: #1e2a3a;
    margin-bottom: 2px;
}

.tl-event.pending {
    color: #bbb;
}

.tl-lokasi {
    font-size: 12px;
    color: #666;
    margin-bottom: 1px;
}

.tl-waktu {
    font-size: 11px;
    color: #aaa;
}

.pulse-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #28a745;
    animation: pulse 1.5s infinite;
    vertical-align: middle;
    margin-right: 4px;
}

@keyframes pulse {

    0%,
    100% {
        opacity: 1;
        transform: scale(1);
    }

    50% {
        opacity: 0.5;
        transform: scale(0.8);
    }
}

.tl-foto-label {
    display: inline-block;
    font-size: 11px;
    font-weight: 700;
    color: #0d6efd;
    background: #e7f1ff;
    border-radius: 4px;
    padding: 1px 8px;
    margin-bottom: 4px;
}
.tl-foto-img {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #e5e5e5;
    cursor: zoom-in;
    display: block;
    margin-top: 4px;
}
.tl-foto-ket { font-size: 12px; color: #555; margin-top: 4px; }
.btn-ulas {
    display: inline-block;
    margin-top: 4px;
    font-size: 11px;
    font-weight: 600;
    color: #e67700;
    background: #fff8e1;
    border: 1px solid #ffe08a;
    border-radius: 6px;
    padding: 2px 8px;
    cursor: pointer;
}
.btn-ulas:hover { background: #ffefb3; }
.ulasan-done { font-size: 11px; color: #2f9e44; margin-top: 4px; }
.ul-bintang { font-size: 32px; line-height: 1; margin-bottom: 12px; }
.ul-star { cursor: pointer; color: #d0d0d0; margin-right: 2px; }
.ul-star.on { color: #f59f00; }
.tracking-loading {
    text-align: center;
    padding: 40px 20px;
    color: #999;
}

.tracking-loading .spinner-border {
    width: 2rem;
    height: 2rem;
    color: #1976d2;
    margin-bottom: 12px;
}

.tracking-error {
    text-align: center;
    padding: 30px 20px;
    color: #721c24;
}
</style>

<div class="riwayat-wrapper">

    <div class="riwayat-header">
        <div class="icon-wrap"><i class="fas fa-shopping-bag"></i></div>
        <h4>Pusat Riwayat Belanja</h4>
    </div>

    @if($pesanan->isEmpty())
    <div class="history-table-wrap">
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <p>Belum ada riwayat belanja.</p>
            <a href="{{ route('customer.produk.index') }}" class="btn btn-primary btn-sm">
                <i class="fas fa-store mr-1"></i> Mulai Belanja
            </a>
        </div>
    </div>

    @else
    <div class="history-table-wrap">
        <div class="history-table-scroll">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Tanggal</th>
                        <th>Total Bayar</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($pesanan as $p)
                    @php
                    $status = strtolower($p->status ?? 'default');
                    $statusSlug = str_replace(' ', '-', $status);
                    $statusClass = in_array($statusSlug,
                    ['pending','proses','dikirim','selesai','dibatalkan','menunggu-pembayaran'])
                    ? 'status-' . $statusSlug
                    : 'status-default';
                    $rowId = 'detail-row-' . $p->id;
                    @endphp
                    <tr data-pesanan-id="{{ $p->id }}">
                        <td>
                            <a href="javascript:void(0)" class="kode-pesanan-link"
                                onclick="toggleDetail('{{ $rowId }}')">
                                {{ $p->kode_pesanan ?? '#' . $p->id }}
                            </a>
                        </td>
                        <td>{{ $p->created_at ? $p->created_at->format('d M Y, H:i') : '-' }}</td>
                        <td class="total-bayar">{{ $p->total_format }}</td>
                        <td>
                            <span class="status-badge {{ $statusClass }}">
                                {{ ucfirst($p->status ?? 'Proses') }}
                            </span>
                        </td>
                        <td>
                            <div class="detail-actions">
                                <button type="button" class="btn-aksi btn-lihat-detail"
                                    onclick="toggleDetail('{{ $rowId }}')">
                                    <i class="fas fa-eye"></i> Lihat Detail
                                </button>
                                <button type="button" class="btn-aksi btn-invoice" data-invoice="{{ json_encode([
                                        'kode'     => $p->kode_pesanan ?? ('#' . $p->id),
                                        'tanggal'  => $p->created_at ? $p->created_at->toIso8601String() : '',
                                        'pemesan'  => optional($p->user)->nama ?? '-',
                                        'penerima' => $p->nama_penerima ?? (optional($p->user)->nama ?? '-'),
                                        'alamat'   => $p->alamat ?? ($p->alamat_pengiriman ?? '-'),
                                        'kode_pos' => $p->kode_pos ?? '',
                                    ]) }}" onclick="cetakInvoice('{{ $rowId }}', this)">
                                    <i class="fas fa-file-invoice"></i> Invoice
                                </button>

                                @if(in_array($status, ['dikirim','selesai']) && !empty($p->no_resi))
                                <button type="button" class="btn-aksi btn-lacak-sm"
                                    onclick="bukaTracking({{ $p->id }}, '{{ $p->kode_pesanan ?? '#'.$p->id }}', '{{ $p->ekspedisi ?? '' }}', '{{ $p->layanan_ekspedisi ?? '' }}', '{{ $p->no_resi ?? '' }}')">
                                    <i class="fas fa-map-marker-alt"></i> Lacak
                                </button>
                                @endif

                                                                @php $fotoBukti = $p->fotoBukti; @endphp
                                @if($fotoBukti->count())
                                <button type="button" class="btn-aksi btn-lacak-sm"
                                    data-foto="{{ json_encode($fotoBukti->map(fn($f) => [
                                        'url'        => asset('storage/' . $f->foto),
                                        'keterangan' => $f->keterangan,
                                        'waktu'      => $f->created_at->format('d M Y, H:i') . ' WIB',
                                    ])->values()) }}"
                                    onclick="bukaGaleriBukti(this)">
                                    <i class="fas fa-camera"></i> Foto Bukti
                                </button>
                                @endif
@if($status === 'menunggu pembayaran')
                                <a href="{{ route('customer.checkout.pembayaran', $p->id) }}"
                                    class="btn-aksi btn-bayar-sm">
                                    <i class="fas fa-credit-card"></i> Bayar
                                </a>
                                @endif
                            </div>
                        </td>
                    </tr>

                    {{-- Row detail (tersembunyi, dibuka lewat tombol Lihat Detail) --}}
                    <tr class="row-detail" id="{{ $rowId }}" style="display:none;">
                        <td colspan="5">
                            <div class="detail-inner">
                                @if($p->details && $p->details->count() > 0)
                                <table class="mini-detail-table">
                                    <thead>
                                        <tr>
                                            <th>Produk</th>
                                            <th class="text-center">Qty</th>
                                            <th class="text-right">Harga</th>
                                            <th class="text-right">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($p->details as $d)
                                        <tr>
                                            <td>
                                            {{ $d->nama_produk ?? ($d->produk->nama_produk ?? '-') }}
                                            @if($status === 'selesai' && $d->produk_id)
                                                @php $pesananSudahUlas = !empty($p->rating_logistik) || collect($sudahUlas)->keys()->contains(fn($k) => str_starts_with($k, $p->id . '-')); @endphp
                                                @if($pesananSudahUlas)
                                                <div class="ulasan-done"><i class="fas fa-check-circle"></i> Sudah diulas</div>
                                                @else
                                                <button type="button" class="btn-ulas"
                                                    data-pesanan="{{ $p->id }}"
                                                    data-produk="{{ $d->produk_id }}"
                                                    data-nama="{{ $d->nama_produk ?? ($d->produk->nama_produk ?? '-') }}"
                                                    onclick="bukaUlasan(this)">
                                                    <i class="fas fa-star"></i> Beri Ulasan
                                                </button>
                                                @endif
                                            @endif
                                        </td>
                                            <td class="text-center">{{ $d->jumlah }}</td>
                                            <td class="text-right">Rp {{ number_format($d->harga, 0, ',', '.') }}</td>
                                            <td class="text-right">Rp {{ number_format($d->subtotal, 0, ',', '.') }}
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                @else
                                <p class="text-muted" style="font-size:12px; margin:0;">Detail produk tidak tersedia.
                                </p>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endif

</div>

{{-- ══════════════════════════════════════════════ --}}
{{-- MODAL TRACKING PENGIRIMAN (tidak diubah)       --}}
{{-- ══════════════════════════════════════════════ --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<div class="modal fade" id="modalUlasan" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="border-radius:12px; overflow:hidden;">
            <form id="formUlasan" enctype="multipart/form-data" onsubmit="return kirimUlasan(event)">
                @csrf
                <input type="hidden" name="produk_id" id="ul-produk-id">
                <input type="hidden" name="rating" id="ul-rating" value="0">
                <div class="modal-header">
                    <h5 class="modal-title">Beri Ulasan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">&times;</button>
                </div>
                <div class="modal-body">
                    <div id="ul-nama" style="font-weight:600; margin-bottom:10px;"></div>
                    <div id="ul-bintang" class="ul-bintang">
                        <span class="ul-star" data-v="1" onclick="setBintang(1)">&#9733;</span>
                        <span class="ul-star" data-v="2" onclick="setBintang(2)">&#9733;</span>
                        <span class="ul-star" data-v="3" onclick="setBintang(3)">&#9733;</span>
                        <span class="ul-star" data-v="4" onclick="setBintang(4)">&#9733;</span>
                        <span class="ul-star" data-v="5" onclick="setBintang(5)">&#9733;</span>
                    </div>
                    <div class="form-group">
                        <label style="font-size:12px; font-weight:600;">Tulis ulasanmu <span class="text-danger">*</span></label>
                        <textarea name="komentar" id="ul-komentar" class="form-control" rows="5" maxlength="1000"
                            oninput="document.getElementById('ul-hitung').textContent = this.value.length"
                            placeholder="Ceritakan pengalamanmu: kualitas produk, kesesuaian ukuran/warna, kemasan, pengiriman, dll. (minimal 10 karakter)"></textarea>
                        <div style="font-size:11px; color:#888; text-align:right;"><span id="ul-hitung">0</span>/1000</div>
                    </div>
                    <div class="form-group" style="margin-bottom:6px;">
                        <label style="font-size:12px; font-weight:600;">Foto (opsional, maks 3 MB)</label>
                        <input type="file" name="foto" class="form-control" accept="image/*">
                    </div>
                    <div id="ul-error" class="text-danger" style="font-size:12px;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-sm btn-primary" id="ul-submit">Kirim Ulasan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade modal-tracking" id="modalTracking" tabindex="-1" role="dialog"
    aria-labelledby="modalTrackingLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content" style="border-radius:12px; overflow:hidden; border:none;">

            <div class="modal-header">
                <h5 class="modal-title" id="modalTrackingLabel">
                    <i class="fas fa-shipping-fast"></i>
                    <span id="mt-kode-pesanan">Lacak Pengiriman</span>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body" style="padding: 20px;">

                <div class="tracking-loading" id="mt-loading">
                    <div class="spinner-border" role="status"></div>
                    <div style="font-size:14px;">Memuat data pengiriman...</div>
                </div>

                <div class="tracking-error" id="mt-error" style="display:none;">
                    <i class="fas fa-exclamation-circle fa-2x mb-2" style="color:#dc3545;"></i>
                    <p style="font-size:13px; margin:0;" id="mt-error-msg">Gagal memuat data tracking.</p>
                </div>

                <div id="mt-content" style="display:none;">

                    <div id="mt-demo" style="display:none;background:#fff3cd;color:#856404;border-radius:6px;padding:6px 10px;font-size:12px;margin-bottom:12px;">
                        Mode contoh: data di bawah bukan data asli dari ekspedisi.
                    </div>

                    <div id="mt-peta-wrap" style="display:none;margin-bottom:14px;">
                        <div id="mt-peta" style="height:200px;border-radius:10px;border:1px solid #dde8f8;"></div>
                        <div id="mt-peta-ket" style="font-size:11px;color:#888;margin-top:4px;"></div>
                    </div>

                    <div class="ekspedisi-info-box">
                        <div class="ekspedisi-logo-box" id="mt-logo">JNE</div>
                        <div class="ekspedisi-detail">
                            <div class="ekspedisi-nama" id="mt-ekspedisi-nama">-</div>
                            <div class="ekspedisi-layanan" id="mt-layanan">-</div>
                            <div class="resi-row">
                                <div>
                                    <div class="resi-label-sm">No. Resi Pengiriman</div>
                                    <div class="resi-value" id="mt-resi">-</div>
                                </div>
                                <button class="resi-copy-btn" onclick="salinResi()">
                                    <i class="far fa-copy"></i> Salin
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="lokasi-box" id="mt-lokasi-box">
                        <div class="lokasi-title">
                            <span class="pulse-dot"></span> Posisi kurir sekarang
                        </div>
                        <div class="lokasi-nama" id="mt-lokasi-nama">-</div>
                        <div class="lokasi-alamat" id="mt-lokasi-alamat"></div>
                        <div class="eta-row">
                            <span class="eta-label-sm"><i class="far fa-clock mr-1"></i>Estimasi tiba</span>
                            <span class="eta-value" id="mt-eta">-</span>
                        </div>
                    </div>

                    <div id="mt-kurir-box" style="display:none;background:#f8f9fa;border:1px solid #e3e6ea;border-radius:8px;padding:10px 14px;margin-bottom:14px;">
                        <div style="font-size:11px;color:#888;">Kurir pengantar</div>
                        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
                            <b id="mt-kurir-nama" style="font-size:13px;"></b>
                            <a id="mt-kurir-telp" href="#" style="font-size:13px;font-weight:600;color:#1976d2;"></a>
                        </div>
                    </div>

                    <div id="mt-rating" style="display:none;text-align:center;border:1px solid #e3e6ea;border-radius:8px;padding:14px;margin-bottom:14px;">
                        <div id="mt-rating-judul" style="font-size:13px;font-weight:700;margin-bottom:10px;"></div>
                        <div id="mt-rating-bintang"></div>
                        <div id="mt-ulasan-form" style="display:none;margin-top:12px;text-align:left;">
                            <textarea id="mt-ulasan-input" class="form-control" rows="3" maxlength="500"
                                placeholder="Tulis pengalamanmu dengan pengiriman (opsional), misalnya kecepatan, kondisi paket, keramahan kurir"></textarea>
                            <div style="font-size:11px;color:#888;text-align:right;"><span id="mt-ulasan-hitung">0</span>/500</div>
                            <button type="button" id="mt-ulasan-kirim" class="btn btn-sm btn-primary" style="margin-top:6px;">Kirim Penilaian</button>
                        </div>
                        <div id="mt-ulasan-teks" style="display:none;margin-top:10px;font-size:13px;color:#444;white-space:pre-wrap;"></div>
                    </div>

                    <div class="tracking-section-title">Riwayat Perjalanan Paket</div>
                    <ul class="timeline-list" id="mt-timeline">
                        {{-- Diisi oleh JS --}}
                    </ul>

                </div>

            </div>

            <div class="modal-footer" style="padding:10px 20px; border-top:1px solid #e8eaf0;">
                <a id="mt-link-cek" href="#" target="_blank" class="btn btn-sm btn-outline-primary"
                    style="font-size:12px;">
                    <i class="fas fa-external-link-alt mr-1"></i> Cek di Website Ekspedisi
                </a>
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"
                    style="font-size:12px;">Tutup</button>
            </div>

        </div>
    </div>
</div>

<script>
// ── Toggle baris detail produk ──
function toggleDetail(rowId) {
    const row = document.getElementById(rowId);
    if (!row) return;
    row.style.display = (row.style.display === 'none' || row.style.display === '') ? 'table-row' : 'none';
}

// ── Data toko (edit sesuai toko kamu) ──
const TOKO = {
    nama: 'BSI Cyber Store',
    alamat: 'Jl. Kramat Raya No.98 RT.02/RW.09, Kramat, Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10450',
    logo: "{{ asset('image/logo.png') }}"
};

function escHtml(t) {
    return String(t ?? '-').replace(/[&<>"']/g, c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    } [c]));
}

// ── Cetak invoice dari isi baris detail ──
function cetakInvoice(rowId, btn) {
    const row = document.getElementById(rowId);
    if (!row) return;

    const d = JSON.parse(btn.dataset.invoice || '{}');

    const tableHtml = row.querySelector('.mini-detail-table')?.outerHTML ??
        '<p>Detail produk tidak tersedia.</p>';

    // Hari, tanggal, dan waktu pesanan dibuat, sesuai zona waktu lokasi pemesan (perangkat)
    let hariTanggal = '-';
    let jam = '-';
    if (d.tanggal) {
        const tgl = new Date(d.tanggal);
        const offsetJam = -tgl.getTimezoneOffset() / 60;
        const labelZona = {
            7: 'WIB',
            8: 'WITA',
            9: 'WIT'
        } [offsetJam] || Intl.DateTimeFormat().resolvedOptions().timeZone;

        hariTanggal = tgl.toLocaleDateString('id-ID', {
            weekday: 'long',
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        });
        jam = tgl.toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit'
        }).replace('.', ':') + ' ' + labelZona;
    }

    const alamatLengkap = escHtml(d.alamat) + (d.kode_pos ? ' (Kode Pos: ' + escHtml(d.kode_pos) + ')' : '');

    const win = window.open('', '_blank');
    win.document.write(`
        <html>
        <head>
            <title>Invoice ${escHtml(d.kode)}</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 30px; color: #1e2a3a; }
                .kop { display: flex; align-items: center; gap: 16px; border-bottom: 3px solid #1976d2; padding-bottom: 14px; margin-bottom: 18px; }
                .kop img { width: 80px; height: 80px; object-fit: contain; }
                .kop h1 { margin: 0 0 4px; font-size: 22px; }
                .kop p { margin: 0; font-size: 13px; color: #555; }
                h2 { margin: 0 0 8px; }
                p { margin: 4px 0; }
                .info { display: flex; gap: 40px; margin-top: 12px; }
                .info > div { flex: 1; }
                .info h4 { margin: 0 0 6px; font-size: 12px; text-transform: uppercase; color: #888; letter-spacing: .05em; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { padding: 8px 10px; border-bottom: 1px solid #ddd; text-align: left; }
                th { background: #f5f7fa; }
            </style>
        </head>
        <body>
            <div class="kop">
                <img src="${TOKO.logo}" alt="Logo">
                <div>
                    <h1>${escHtml(TOKO.nama)}</h1>
                    <p>${escHtml(TOKO.alamat)}</p>
                </div>
            </div>

            <h2>Invoice</h2>
            <p>Kode Pesanan: <strong>${escHtml(d.kode)}</strong></p>
            <p>Hari/Tanggal: <strong>${hariTanggal}</strong></p>
            <p>Waktu: <strong>${jam}</strong></p>

            <div class="info">
                <div>
                    <h4>Pemesan</h4>
                    <p><strong>${escHtml(d.pemesan)}</strong></p>
                </div>
                <div>
                    <h4>Penerima</h4>
                    <p><strong>${escHtml(d.penerima)}</strong></p>
                    <p>${alamatLengkap}</p>
                </div>
            </div>

            ${tableHtml}

            <script>
                window.onload = function () { window.focus(); window.print(); };
            <\/script>
        </body>
        </html>
    `);
    win.document.close();
}

// ── Peta ikon & link ekspedisi ──
const EKSPEDISI_MAP = {
    'jne': {
        label: 'JNE',
        nama: 'JNE Express',
        link: 'https://www.jne.co.id/id/tracking/trace/'
    },
    'jnt': {
        label: 'J&T',
        nama: 'J&T Express',
        link: 'https://www.jet.co.id/track'
    },
    'sicepat': {
        label: 'SiCepat',
        nama: 'SiCepat Express',
        link: 'https://sicepat.com/checkAwb'
    },
    'anteraja': {
        label: 'Anteraja',
        nama: 'Anteraja',
        link: 'https://anteraja.id/tracking'
    },
    'pos': {
        label: 'POS ID',
        nama: 'POS Indonesia',
        link: 'https://www.posindonesia.co.id/id/tracking'
    },
    'tiki': {
        label: 'TIKI',
        nama: 'TIKI',
        link: 'https://www.tiki.id/id/tracking'
    },
    'ninja': {
        label: 'Ninja',
        nama: 'Ninja Xpress',
        link: 'https://www.ninjaxpress.co/id-id/tracking'
    },
    'sap': {
        label: 'SAP',
        nama: 'SAP Express',
        link: 'https://sap-express.id/track'
    },
};

function bukaGaleriBukti(btn) {
    let list = [];
    try { list = JSON.parse(btn.dataset.foto || '[]'); } catch (e) {}
    if (!list.length) return;

    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:3000;overflow:auto;padding:24px 16px;cursor:zoom-out;';
    const judul = document.createElement('div');
    judul.textContent = 'Foto dari penjual';
    judul.style.cssText = 'color:#fff;font-weight:700;text-align:center;margin-bottom:16px;';
    ov.appendChild(judul);

    list.forEach(f => {
        const box = document.createElement('div');
        box.style.cssText = 'max-width:640px;margin:0 auto 20px;text-align:center;color:#ddd;font-size:13px;';
        const img = document.createElement('img');
        img.src = f.url;
        img.style.cssText = 'max-width:100%;border-radius:8px;';
        box.appendChild(img);
        if (f.keterangan) {
            const k = document.createElement('div');
            k.textContent = f.keterangan;
            k.style.marginTop = '6px';
            box.appendChild(k);
        }
        const w = document.createElement('div');
        w.textContent = f.waktu || '';
        w.style.cssText = 'font-size:12px;color:#aaa;';
        box.appendChild(w);
        ov.appendChild(box);
    });

    ov.addEventListener('click', () => ov.remove());
    document.body.appendChild(ov);
}
function bukaUlasan(btn) {
    document.getElementById('formUlasan').reset();
    document.getElementById('ul-produk-id').value = btn.dataset.produk;
    document.getElementById('ul-nama').textContent = btn.dataset.nama || '';
    document.getElementById('ul-error').textContent = '';
    document.getElementById('ul-hitung').textContent = '0';
    window.ulasanPesananId = btn.dataset.pesanan;
    setBintang(0);
    $('#modalUlasan').modal('show');
}

function setBintang(n) {
    document.getElementById('ul-rating').value = n;
    document.querySelectorAll('#ul-bintang .ul-star').forEach(s => {
        s.classList.toggle('on', parseInt(s.dataset.v) <= n);
    });
}

function kirimUlasan(e) {
    e.preventDefault();
    const err = document.getElementById('ul-error');
    err.textContent = '';
    if (!parseInt(document.getElementById('ul-rating').value)) {
        err.textContent = 'Pilih jumlah bintang dulu.';
        return false;
    }
    if (document.getElementById('ul-komentar').value.trim().length < 10) {
        err.textContent = 'Tulis ulasanmu dulu, minimal 10 karakter.';
        return false;
    }
    const btn = document.getElementById('ul-submit');
    btn.disabled = true;

    fetch(`/customer/pesanan/${window.ulasanPesananId}/ulasan`, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
        body: new FormData(document.getElementById('formUlasan'))
    })
    .then(async res => {
        const j = await res.json().catch(() => ({}));
        if (!res.ok) {
            let msg = j.message || 'Gagal mengirim ulasan.';
            if (j.errors) msg = Object.values(j.errors).flat().join(' ');
            throw new Error(msg);
        }
        $('#modalUlasan').modal('hide');
        alert('Terima kasih, ulasan kamu sudah terkirim.');
        location.reload();
    })
    .catch(ex => { err.textContent = ex.message; })
    .finally(() => { btn.disabled = false; });

    return false;
}
let currentResi = '';

function bukaTracking(idPesanan, kodePesanan, ekspedisi, layanan, resi) {
    document.getElementById('mt-loading').style.display = 'block';
    document.getElementById('mt-content').style.display = 'none';
    document.getElementById('mt-error').style.display = 'none';
    resetTambahan();

    document.getElementById('mt-kode-pesanan').textContent = 'Lacak — ' + kodePesanan;

    currentResi = resi;

    $('#modalTracking').modal('show');

    fetch(`/customer/pesanan/${idPesanan}/tracking`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => {
            if (!res.ok) throw new Error('Server error ' + res.status);
            return res.json();
        })
        .then(data => {
            renderTracking(data, ekspedisi, layanan, resi);
            renderTambahan(data, idPesanan);
        })
        .catch(err => {
            renderTrackingFallback(ekspedisi, layanan, resi);
        });
}

function renderTracking(data, ekspedisi, layanan, resi) {
    if (data.tersedia === false) {
        renderTrackingFallback(ekspedisi, layanan, resi, data.pesan);
        return;
    }
    const eksp = (data.ekspedisi || ekspedisi || '').toLowerCase();
    const lay = data.layanan || layanan || '-';
    const noResi = data.no_resi || resi || '-';
    const eta = data.estimasi_tiba || 'Dalam estimasi 1–2 hari kerja';

    isiTampilanEkspedisi(eksp, lay, noResi, eta);
    document.querySelector('#mt-lokasi-box .lokasi-title').innerHTML =
        '<span class="pulse-dot"></span> Posisi kurir sekarang';

    if (data.posisi_sekarang) {
        document.getElementById('mt-lokasi-nama').textContent = data.posisi_sekarang.nama || '-';
        document.getElementById('mt-lokasi-alamat').textContent = data.posisi_sekarang.alamat || '';
    } else {
        document.getElementById('mt-lokasi-nama').textContent = 'Data posisi belum tersedia';
        document.getElementById('mt-lokasi-alamat').textContent = '';
    }

    document.getElementById('mt-eta').textContent = eta;

    const timeline = data.riwayat || [];
    renderTimeline(timeline);

    tampilkanKonten();
}

function renderTrackingFallback(ekspedisi, layanan, resi, pesan) {
    const eksp = (ekspedisi || '').toLowerCase();

    isiTampilanEkspedisi(eksp, layanan || '-', resi, '-');
    document.querySelector('#mt-lokasi-box .lokasi-title').innerHTML =
        '<span class="pulse-dot" style="background:#adb5bd;animation:none;"></span> Status pelacakan';

    document.getElementById('mt-lokasi-nama').textContent = 'Data pelacakan belum tersedia';
    document.getElementById('mt-lokasi-alamat').textContent = pesan || 'Silakan cek langsung di website ekspedisi.';
    document.getElementById('mt-eta').textContent = '-';

    renderTimeline([]);
    tampilkanKonten();
}
function isiTampilanEkspedisi(eksp, layanan, resi, eta) {
    const info = EKSPEDISI_MAP[eksp] || {
        label: eksp.toUpperCase() || '?',
        nama: eksp || 'Ekspedisi',
        link: '#'
    };

    document.getElementById('mt-logo').textContent = info.label;
    document.getElementById('mt-ekspedisi-nama').textContent = info.nama;
    document.getElementById('mt-layanan').textContent = layanan !== '-' ? 'Layanan: ' + layanan : '';
    document.getElementById('mt-resi').textContent = resi || '-';

    const linkEl = document.getElementById('mt-link-cek');
    linkEl.href = resi ? (info.link + resi) : info.link;
}

function renderTimeline(items) {
    const ul = document.getElementById('mt-timeline');
    ul.innerHTML = '';

    const ikonMap = {
        'current': {
            icon: 'fas fa-truck',
            cls: 'current'
        },
        'done': {
            icon: 'fas fa-check',
            cls: 'done'
        },
        'pending': {
            icon: 'fas fa-circle',
            cls: 'pending'
        },
    };

    items.forEach((item, idx) => {
        const tipe = item.tipe || (idx === 0 ? 'current' : 'done');
        const m = ikonMap[tipe] || ikonMap['done'];

        const li = document.createElement('li');
        li.innerHTML = `
            <div class="tl-icon-wrap">
                <div class="tl-icon ${m.cls}">
                    <i class="${m.icon}" style="font-size:11px;"></i>
                </div>
            </div>
            <div class="tl-content">
                <div class="tl-event ${tipe === 'pending' ? 'pending' : ''}">${escHtml(item.status || '-')}</div>
                ${item.lokasi ? `<div class="tl-lokasi"><i class="fas fa-map-marker-alt" style="font-size:10px;margin-right:3px;"></i>${escHtml(item.lokasi)}</div>` : ''}
                ${item.waktu  ? `<div class="tl-waktu"><i class="far fa-clock" style="font-size:10px;margin-right:3px;"></i>${escHtml(item.waktu)}</div>`  : ''}
            </div>
        `;
        ul.appendChild(li);
    });

    if (items.length === 0) {
        ul.innerHTML =
            '<li><div class="tl-content"><div class="tl-event pending">Belum ada riwayat perjalanan.</div></div></li>';
    }
}

function bukaFotoBukti(url) {
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:3000;display:flex;align-items:center;justify-content:center;cursor:zoom-out;padding:16px;';
    const img = document.createElement('img');
    img.src = url;
    img.style.cssText = 'max-width:100%;max-height:100%;border-radius:8px;';
    ov.appendChild(img);
    ov.addEventListener('click', () => ov.remove());
    document.body.appendChild(ov);
}

function renderFotoBukti(list) {
    const ul = document.getElementById('mt-timeline');
    if (!ul) return;
    ul.querySelectorAll('li.tl-foto').forEach(el => el.remove());
    if (!Array.isArray(list) || list.length === 0) return;

    if (ul.children.length === 1 && ul.textContent.indexOf('Belum ada riwayat') !== -1) {
        ul.innerHTML = '';
    }

    // list terbaru di index 0, disisipkan dari belakang supaya yang terbaru paling atas
    for (let i = list.length - 1; i >= 0; i--) {
        const f = list[i];
        const li = document.createElement('li');
        li.className = 'tl-foto';
        li.innerHTML = `
            <div class="tl-icon-wrap">
                <div class="tl-icon done">
                    <i class="fas fa-camera" style="font-size:11px;"></i>
                </div>
            </div>
            <div class="tl-content">
                <span class="tl-foto-label">Foto dari penjual</span>
                <img class="tl-foto-img" src="${escHtml(f.url)}" alt="Foto dari penjual">
                ${f.keterangan ? `<div class="tl-foto-ket">${escHtml(f.keterangan)}</div>` : ''}
                ${f.waktu ? `<div class="tl-waktu"><i class="far fa-clock" style="font-size:10px;margin-right:3px;"></i>${escHtml(f.waktu)}</div>` : ''}
            </div>
        `;
        li.querySelector('img').addEventListener('click', () => bukaFotoBukti(f.url));
        ul.insertBefore(li, ul.firstChild);
    }
}
let petaObj = null;

function resetTambahan() {
    ['mt-peta-wrap', 'mt-kurir-box', 'mt-rating', 'mt-demo'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}

function renderTambahan(data, idPesanan) {
    document.getElementById('mt-demo').style.display = data.demo ? 'block' : 'none';
    renderPeta(data.peta);
    renderKurir(data.kurir);
    renderRating(data, idPesanan);
    renderFotoBukti(data.foto_bukti);
}

function renderPeta(peta) {
    const wrap = document.getElementById('mt-peta-wrap');
    if (!peta || (!peta.asal && !peta.tujuan) || typeof L === 'undefined') {
        wrap.style.display = 'none';
        return;
    }

    wrap.style.display = 'block';
    if (petaObj) {
        petaObj.remove();
        petaObj = null;
    }

    petaObj = L.map('mt-peta', {
        scrollWheelZoom: false
    });
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '&copy; OpenStreetMap'
    }).addTo(petaObj);

    const titik = [];
    if (peta.asal) {
        const p = [peta.asal.lat, peta.asal.lng];
        L.marker(p).addTo(petaObj).bindTooltip('Asal: BSI Cyber Store');
        titik.push(p);
    }
    if (peta.tujuan) {
        const p = [peta.tujuan.lat, peta.tujuan.lng];
        L.marker(p).addTo(petaObj).bindTooltip('Tujuan: alamat penerima');
        titik.push(p);
    }
    if (titik.length > 1) {
        L.polyline(titik, {
            color: '#1976d2',
            weight: 3,
            dashArray: '6 8'
        }).addTo(petaObj);
    }

    document.getElementById('mt-peta-ket').textContent =
        'Pin asal dan alamat tujuan. Garis putus-putus hanya penunjuk arah, bukan rute kurir.';

    setTimeout(() => {
        petaObj.invalidateSize();
        if (titik.length > 1) petaObj.fitBounds(titik, {
            padding: [30, 30]
        });
        else petaObj.setView(titik[0], 13);
    }, 400);
}

function renderKurir(k) {
    const box = document.getElementById('mt-kurir-box');
    if (!k) {
        box.style.display = 'none';
        return;
    }
    document.getElementById('mt-kurir-nama').textContent = k.nama || 'Kurir';
    const tel = document.getElementById('mt-kurir-telp');
    if (k.telp) {
        tel.textContent = k.telp;
        tel.href = 'tel:' + k.telp;
        tel.style.display = 'inline';
    } else {
        tel.style.display = 'none';
    }
    box.style.display = 'block';
}

let ratingPilihan = 0;

function renderRating(data, idPesanan) {
    const box = document.getElementById('mt-rating');
    if (!data.bisa_rating) {
        box.style.display = 'none';
        return;
    }
    box.style.display = 'block';
    ratingPilihan = data.rating_logistik || 0;
    if (data.sudah_ulas_produk && !data.rating_logistik) {
        document.getElementById('mt-rating-judul').textContent = 'Kamu sudah mengulas produk pesanan ini.';
        document.getElementById('mt-rating-bintang').innerHTML = '';
        document.getElementById('mt-ulasan-form').style.display = 'none';
        document.getElementById('mt-ulasan-teks').style.display = 'none';
        return;
    }
    gambarBintang(ratingPilihan, idPesanan, !!data.rating_logistik, data.ulasan_logistik || '');
}

function gambarBintang(nilai, idPesanan, terkunci, ulasan) {
    const wrap = document.getElementById('mt-rating-bintang');
    const form = document.getElementById('mt-ulasan-form');
    const input = document.getElementById('mt-ulasan-input');
    const teks = document.getElementById('mt-ulasan-teks');
    wrap.innerHTML = '';
    document.getElementById('mt-rating-judul').textContent = terkunci ?
        'Terima kasih atas penilaian Anda untuk logistik' :
        'Seberapa puaskah Anda dengan logistik?';

    for (let i = 1; i <= 5; i++) {
        const b = document.createElement('i');
        b.className = (i <= nilai ? 'fas' : 'far') + ' fa-star';
        b.style.cssText = 'font-size:26px;margin-right:10px;color:' + (i <= nilai ? '#f5a623' : '#c4c9d1') +
            ';cursor:' + (terkunci ? 'default' : 'pointer');
        if (!terkunci) b.addEventListener('click', () => {
            ratingPilihan = i;
            gambarBintang(i, idPesanan, false, input.value);
        });
        wrap.appendChild(b);
    }

    if (terkunci) {
        form.style.display = 'none';
        teks.style.display = ulasan ? 'block' : 'none';
        teks.textContent = ulasan || '';
    } else {
        teks.style.display = 'none';
        form.style.display = nilai > 0 ? 'block' : 'none';
        input.value = ulasan || '';
        document.getElementById('mt-ulasan-hitung').textContent = input.value.length;
        input.oninput = () => {
            document.getElementById('mt-ulasan-hitung').textContent = input.value.length;
        };
        document.getElementById('mt-ulasan-kirim').onclick = () => kirimRating(idPesanan);
    }
}

function kirimRating(idPesanan) {
    if (!ratingPilihan) return;
    const nilai = ratingPilihan;
    const ulasan = document.getElementById('mt-ulasan-input').value.trim();
    const btn = document.getElementById('mt-ulasan-kirim');
    btn.disabled = true;

    fetch(`/customer/pesanan/${idPesanan}/rating-logistik`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                rating: nilai,
                ulasan: ulasan
            })
        })
        .then(async r => {
            const j = await r.json().catch(() => ({}));
            if (!r.ok) throw new Error(j.message || 'gagal');
            return j;
        })
        .then(() => gambarBintang(nilai, idPesanan, true, ulasan))
        .catch(e => alert(e.message && e.message !== 'gagal' ? e.message : 'Gagal menyimpan penilaian. Coba lagi.'))
        .finally(() => { btn.disabled = false; });
}
function tampilkanKonten() {
    document.getElementById('mt-loading').style.display = 'none';
    document.getElementById('mt-content').style.display = 'block';
}

function salinResi() {
    if (!currentResi) return;
    navigator.clipboard.writeText(currentResi)
        .then(() => {
            const btn = document.querySelector('.resi-copy-btn');
            btn.innerHTML = '<i class="fas fa-check"></i> Disalin!';
            setTimeout(() => {
                btn.innerHTML = '<i class="far fa-copy"></i> Salin';
            }, 2000);
        })
        .catch(() => alert('Resi: ' + currentResi));
}

// ── Auto-buka tracking/detail kalau datang dari link notifikasi ──
document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const lacakId = params.get('lacak');
    const highlightId = params.get('highlight');

    if (lacakId) {
        const row = document.querySelector(`tr[data-pesanan-id="${lacakId}"]`);
        const btn = row ? row.querySelector('.btn-lacak-sm') : null;
        if (btn) btn.click();
    }

    if (highlightId) {
        const row = document.querySelector(`tr[data-pesanan-id="${highlightId}"]`);
        if (row) {
            row.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
            row.style.background = '#fff8e1';
            const kodeLink = row.querySelector('.kode-pesanan-link');
            if (kodeLink) kodeLink.click();
        }
    }
});
</script>

@endsection