<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Terapkan tema tersimpan sebelum halaman dirender (anti kedip) -->
    <script>
    (function() {
        var saved = null;
        try {
            saved = localStorage.getItem('theme');
        } catch (e) {}
        var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', saved || (prefersDark ? 'dark' : 'light'));
    })();
    </script>

    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('image/icon_univ_bsi.png') }}">
    <title>tokoonline</title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">

    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="{{ asset('frontend/css/slick.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('frontend/css/slick-theme.css') }}">

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="{{ asset('frontend/css/nouislider.min.css') }}">

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="{{ asset('frontend/css/font-awesome.min.css') }}">

    <!-- Custom stylesheet -->
    <link type="text/css" rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <style>
    /* ===== HEADER STICKY (BARU) ===== */
    #siteHeader {
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        z-index: 1030;
        background: #fff;
        transition: box-shadow 0.2s ease;
    }

    #siteHeader.scrolled {
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
    }

    [data-theme="dark"] #siteHeader {
        background: #1e1e1e;
    }

    /* ===== HEADER RESPONSIVE (TAMPILAN HP) ===== */
    @media (max-width: 767px) {

        /* --- Bar atas: "Selamat datang" kiri, jam + tanggal kanan, satu baris --- */
        #top-header {
            padding: 0;
        }

        #top-header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: nowrap;
            padding: 6px 12px;
        }

        #top-header .container::before,
        #top-header .container::after {
            display: none !important;
        }

        #top-header .pull-left,
        #top-header .pull-right {
            float: none !important;
        }

        #top-header .pull-left {
            flex: 1 1 auto;
            min-width: 0;
            margin-right: 8px;
        }

        #top-header .pull-left span {
            display: block;
            font-size: 12px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        #top-header .pull-right {
            flex: 0 0 auto;
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
            white-space: nowrap;
        }

        #top-header .theme-toggle {
            width: 26px;
            height: 26px;
            padding: 0;
            font-size: 13px;
            line-height: 1;
        }

        #tanggalRealtimeCustomer {
            margin-left: 0 !important;
        }

        /* --- Bar utama: logo kiri, ikon (keranjang, notif, akun, menu) kanan --- */
        #header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: nowrap;
            padding: 8px 12px;
        }

        #header .container::before,
        #header .container::after {
            display: none !important;
        }

        #header .pull-left,
        #header .pull-right {
            float: none !important;
        }

        #header .header-logo {
            padding: 0;
            margin: 0;
        }

        #header .header-logo .logo img {
            height: 46px;
            width: auto;
            max-height: none;
        }

        #header .header-btns {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        #header .header-btns>li {
            float: none !important;
            display: block !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        /* Ikon saja, teks label disembunyikan biar muat */
        #header .header-btns>li strong {
            display: none !important;
        }

        #header .header-btns .header-btns-icon {
            float: none !important;
            width: 40px !important;
            height: 40px !important;
            line-height: 38px !important;
            margin: 0 !important;
            font-size: 16px;
            text-align: center;
        }

        #notifBadge {
            top: -8px;
            right: -8px;
        }

        /* Tombol hamburger menu */
        #header .nav-toggle-btn {
            width: 40px;
            height: 40px;
            padding: 0;
            line-height: 38px;
        }

        /* Dropdown jangan keluar layar */
        #header .header-btns .custom-menu {
            right: 0 !important;
            left: auto !important;
            max-width: calc(100vw - 24px);
        }

        .header-notif .custom-menu {
            width: 280px;
        }
    }

    /* HP kecil: rapatkan lagi */
    @media (max-width: 400px) {
        #top-header .pull-left span {
            font-size: 11px;
        }

        #top-header .pull-right {
            font-size: 10px;
            gap: 4px;
        }

        #header .header-btns {
            gap: 6px;
        }

        #header .header-btns .header-btns-icon,
        #header .nav-toggle-btn {
            width: 36px !important;
            height: 36px !important;
            line-height: 34px !important;
        }
    }

    /* ===== PERBAIKAN MENU HAMBURGER (TERTUTUP HEADER STICKY) ===== */
    @media (max-width: 991px) {
        #responsive-nav {
            z-index: 1100 !important;
        }
    }

    /* ===== PERBAIKAN DROPDOWN DI HP: lebar penuh di bawah bar logo, dibuka dengan klik/tap ===== */
    @media (max-width: 767px) {
        #header {
            position: relative !important;
        }

        #header .header-btns>li.dropdown {
            position: static !important;
        }

        #header .header-btns>li.dropdown .custom-menu {
            position: absolute !important;
            top: 100% !important;
            left: 12px !important;
            right: 12px !important;
            width: auto !important;
            min-width: 0 !important;
            max-width: none !important;
            margin: 0 !important;
            transform: none !important;
            max-height: 60vh;
            overflow-y: auto;
            z-index: 1040;
        }

        /* Matikan hover, buka hanya saat diklik/tap */
        #header .header-btns>li.dropdown:hover .custom-menu {
            display: none !important;
            opacity: 0 !important;
            visibility: hidden !important;
        }

        #header .header-btns>li.dropdown.open .custom-menu,
        #header .header-btns>li.dropdown.open:hover .custom-menu {
            display: block !important;
            opacity: 1 !important;
            visibility: visible !important;
        }
    }

    /* ===== KONTEN HALAMAN SELEBAR LAYAR DI HP/TABLET ===== */
    /* Kolom tanpa class col-xs/col-sm (mis. col-md-12) tadinya menyusut mengikuti isinya,
       sehingga keranjang, akun, wishlist, dan bandingkan terlihat sempit/terpotong. */
    @media (max-width: 991px) {
        #store .row>:not([class*="col-xs-"]):not([class*="col-sm-"]):not(.clearfix) {
            width: 100%;
            max-width: 100%;
            min-width: 0;
            box-sizing: border-box;
        }
    }

    /* ===== KATEGORI ICON ANIMATION ===== */
    .kategori-icon-anim {
        display: inline-block;
        animation: kategoriWiggle 2.5s ease-in-out infinite;
    }

    @keyframes kategoriWiggle {

        0%,
        100% {
            transform: rotate(0deg);
        }

        10% {
            transform: rotate(-15deg);
        }

        20% {
            transform: rotate(15deg);
        }

        30% {
            transform: rotate(-10deg);
        }

        40% {
            transform: rotate(10deg);
        }

        50% {
            transform: rotate(0deg);
        }
    }

    .category-header:hover .kategori-icon-anim {
        animation: kategoriSpin 0.6s linear infinite;
    }

    @keyframes kategoriSpin {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }

    /* ===== NOTIFIKASI STYLES ===== */
    .header-notif .header-btns-icon {
        position: relative;
    }

    #notifBadge {
        display: none;
        position: absolute;
        top: -6px;
        right: -10px;
        background: #e74c3c;
        color: #fff;
        font-size: 10px;
        line-height: 1;
        border-radius: 10px;
        padding: 3px 5px;
        font-weight: bold;
    }

    .header-notif .custom-menu {
        width: 320px;
        max-height: 400px;
        overflow-y: auto;
        right: 0;
        left: auto;
    }

    .notif-heading {
        padding: 8px 15px;
        font-weight: bold;
        border-bottom: 1px solid #eee;
        cursor: default;
    }

    .notif-item {
        display: block;
        position: relative;
        padding: 10px 15px 10px 28px;
        border-bottom: 1px solid #f2f2f2;
        color: inherit;
        text-decoration: none;
        transition: background 0.15s;
    }

    a.notif-item:hover {
        background: #f7f9fc;
        color: inherit;
        text-decoration: none;
    }

    .notif-item.notif-unread {
        background: #eaf3ff;
    }

    .notif-item.notif-unread:hover {
        background: #dcebff;
    }

    .notif-item .notif-dot {
        display: none;
        position: absolute;
        left: 12px;
        top: 16px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #1976d2;
    }

    .notif-item.notif-unread .notif-dot {
        display: block;
    }

    .notif-item .notif-title {
        font-weight: 600;
        font-size: 13px;
    }

    .notif-item .notif-sub {
        color: #666;
        font-size: 12px;
    }

    .notif-item .notif-time {
        color: #aaa;
        font-size: 11px;
    }

    .notif-empty,
    .notif-error {
        padding: 15px;
        text-align: center;
        color: #999;
    }

    .notif-error {
        color: #c00;
    }

    .header-btns>li.dropdown {
        position: relative;
    }

    .header-btns>li.dropdown .custom-menu {
        display: none;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.2s ease;
    }

    .header-btns>li.dropdown:hover .custom-menu {
        display: block !important;
        opacity: 1;
        visibility: visible;
    }

    /* ===== TOAST SELAMAT DATANG (muncul dari atas) ===== */
    .bsi-toast {
        position: fixed !important;
        top: 20px !important;
        left: 50% !important;
        right: auto !important;
        z-index: 10000;
        display: flex !important;
        flex-direction: row !important;
        align-items: center !important;
        gap: 12px;
        width: max-content;
        max-width: calc(100vw - 32px);
        box-sizing: border-box;
        padding: 14px 18px;
        background: #fff;
        color: #2b2b2b;
        border-left: 4px solid #F8694A;
        border-radius: 8px;
        box-shadow: 0 8px 28px rgba(0, 0, 0, 0.2);
        transform: translate(-50%, -160%);
        opacity: 0;
        transition: transform 0.5s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease;
    }

    .bsi-toast.show {
        transform: translate(-50%, 0);
        opacity: 1;
    }

    .bsi-toast .bsi-toast-icon {
        flex: 0 0 auto;
        font-size: 26px;
        line-height: 1;
    }

    .bsi-toast .bsi-toast-text {
        flex: 1 1 auto;
        font-size: 14px;
        line-height: 1.5;
    }

    .bsi-toast .bsi-toast-close {
        flex: 0 0 auto;
        background: none;
        border: none;
        color: inherit;
        font-size: 20px;
        line-height: 1;
        opacity: 0.6;
        cursor: pointer;
        padding: 0 2px;
    }

    .bsi-toast .bsi-toast-close:hover {
        opacity: 1;
    }

    [data-theme="dark"] .bsi-toast {
        background: #1e1e1e;
        color: #f1f1f1;
        box-shadow: 0 8px 28px rgba(0, 0, 0, 0.6);
    }
    </style>

    <!-- Dark mode (taruh paling akhir supaya override-nya kepake) -->
    <link rel="stylesheet" href="{{ asset('css/dark-mode.css') }}">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- HEADER (sekarang sticky, lihat id="siteHeader") -->
    <header id="siteHeader">
        <!-- top Header -->
        <div id="top-header">
            <div class="container">
                <div class="pull-left">
                    <span>Selamat datang di BSI Cyber Store</span>
                </div>
                <div class="pull-right">
                    <button type="button" id="themeToggle" class="theme-toggle" aria-label="Ganti tema">🌙</button>
                    <span id="jamRealtimeCustomer" style="font-weight:600;"></span>
                    <span id="tanggalRealtimeCustomer" style="margin-left:8px;"></span>
                </div>
            </div>
        </div>
        <!-- /top Header -->

        <!-- header -->
        <div id="header">
            <div class="container">
                <div class="pull-left">
                    <!-- Logo -->
                    <div class="header-logo">
                        <a class="logo" href="#">
                            <img src="{{ asset('image/logo.png') }}" alt="">
                        </a>
                    </div>
                    <!-- /Logo -->
                </div>
                <div class="pull-right">
                    <ul class="header-btns">
                        <!-- Cart -->
                        <li class="header-cart dropdown default-dropdown">
                            <a href="{{ route('order.cart') }}">
                                <div class="header-btns-icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <strong class="text-uppercase">Keranjang</strong>
                            </a>
                        </li>
                        <!-- /Cart -->

                        @auth
                        <!-- Notifikasi -->
                        <li class="header-notif dropdown default-dropdown">
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-bell-o"></i>
                                    <span id="notifBadge">0</span>
                                </div>
                                <strong class="text-uppercase">Notifikasi <i class="fa fa-caret-down"></i></strong>
                            </div>
                            <ul class="custom-menu">
                                <li class="notif-heading">Notifikasi Terbaru</li>
                                <li id="notifList">
                                    <div class="notif-empty">Memuat...</div>
                                </li>
                            </ul>
                        </li>
                        <!-- /Notifikasi -->
                        @endauth

                        <!-- Account -->
                        <li class="header-account dropdown default-dropdown">
                            @if (Auth::check())
                            <!-- Tampilan Setelah Login -->
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-user-o"></i>
                                </div>
                                <strong class="text-uppercase">{{ Auth::user()->nama }} <i
                                        class="fa fa-caret-down"></i></strong>
                            </div>
                            <ul class="custom-menu">
                                <li><a href="{{ route('customer.akun', ['id' => Auth::user()->id]) }}"><i
                                            class="fa fa-user-o"></i> Akun Saya</a></li>
                                <li><a href="{{ route('customer.riwayat.index') }}"><i class="fa fa-check"></i>
                                        Riwayat</a></li>
                                <li>
                                    <a href="{{ route('logout') }}"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="fa fa-power-off"></i> Keluar
                                    </a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                        style="display: none;">
                                        @csrf
                                    </form>
                                </li>
                            </ul>
                            @else
                            <!-- Tampilan Sebelum Login -->
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-user-o"></i>
                                </div>
                                <strong class="text-uppercase">Akun Saya <i class="fa fa-caret-down"></i></strong>
                            </div>
                            <ul class="custom-menu">
                                <li><a href="{{ route('customer.login') }}"><i class="fa fa-user"></i> Login sebagai
                                        Customer</a></li>
                                <li><a href="{{ route('backend.login') }}"><i class="fa fa-shield"></i> Login sebagai
                                        Admin</a></li>
                            </ul>
                            @endif
                        </li>
                        <!-- /Account -->

                        <!-- Mobile nav toggle-->
                        <li class="nav-toggle">
                            <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                        </li>
                        <!-- / Mobile nav toggle -->
                    </ul>
                </div>
            </div>
            <!-- /header -->
        </div>
    </header>
    <!-- /HEADER -->

    <!-- NAVIGATION -->
    <div id="navigation">
        <div class="container">
            <div id="responsive-nav">
                <!-- category nav -->
                <div class="category-nav">
                    <span class="category-header">Kategori <i class="fa fa-list kategori-icon-anim"></i></span>
                    <ul class="category-list">
                        @foreach ($kategoris as $kategori)
                        <li><a href="{{ route('produk.kategori', $kategori->id) }}">{{ $kategori->nama_kategori }}</a>
                        </li>
                        @endforeach
                        <li><a href="{{ route('customer.produk.index') }}">Lihat Semua</a></li>
                    </ul>
                </div>
                <!-- /category nav -->

                <!-- menu nav -->
                <div class="menu-nav">
                    <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                    <ul class="menu-list">
                        <li><a href="{{ route('beranda') }}">Beranda</a></li>
                        <li><a href="{{ route('customer.produk.index') }}">Produk</a></li>
                        <li><a href="https://maps.app.goo.gl/mszkz9TNzRnMFh9M7" target="_blank"
                                rel="noopener">Lokasi</a></li>
                        <li><a href="{{ route('kontak') }}">Hubungi Kami</a></li>
                        <li><a href="{{ route('karir.index') }}">Karir</a></li>
                    </ul>
                </div>
                <!-- /menu nav -->
            </div>
        </div>
    </div>
    <!-- /NAVIGATION -->

    <!-- HOME -->
    @if (request()->segment(1) == '' || request()->segment(1) == 'beranda')
    <div id="home">
        <div class="container">
            <div class="home-wrap">
                <div id="home-slick">
                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{ asset('frontend/img/banner01.jpg') }}" alt="">
                        <div class="banner-caption text-center">
                            <h1>Diskon Tas</h1>
                            <h3 class="white-color font-weak">Diskon hingga 50%</h3>
                            <a href="{{ $produkBanner1 ? route('produk.detail', $produkBanner1->id) : '#' }}"
                                class="primary-btn">Belanja Sekarang</a>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{ asset('frontend/img/banner02.jpg') }}" alt="">
                        <div class="banner-caption">
                            <h1 class="primary-color">PROMO PANAS<br><span class="white-color font-weak">Diskon hingga
                                    50%</span></h1>
                            <a href="{{ $produkBanner2 ? route('produk.detail', $produkBanner2->id) : '#' }}"
                                class="primary-btn">Belanja Sekarang</a>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{ asset('frontend/img/banner03.jpg') }}" alt="">
                        <div class="banner-caption">
                            <h1 class="white-color">Koleksi <span>Produk Baru</span></h1>
                            <a href="{{ $produkBanner3 ? route('produk.detail', $produkBanner3->id) : '#' }}"
                                class="primary-btn">Belanja Sekarang</a>
                        </div>
                    </div>
                    <!-- /banner -->
                </div>
            </div>
        </div>
    </div>
    @endif
    <!-- /HOME -->

    <!-- section -->
    <div class="section">
        <div class="container">
            <div class="row">
                <!-- ASIDE -->
                <div id="aside"
                    class="col-md-3 {{ request()->segment(1) == '' || request()->segment(1) == 'beranda' ? '' : 'hidden-xs hidden-sm' }}">
                    <!-- aside widget -->
{{-- terlaris-only-home --}}
    @if (request()->segment(1) == '' || request()->segment(1) == 'beranda')
                    <div class="aside">
                        <h3 class="aside-title">Produk Terlaris</h3>

                        @php
                        // 3 produk aktif dengan jumlah transaksi terbanyak
                        $produkTerlaris = \App\Models\Produk::withCount('pesananDetail')
                        ->where('status', 1)
                        ->orderByDesc('pesanan_detail_count')
                        ->take(3)
                        ->get();
                        @endphp

                        @forelse ($produkTerlaris as $pt)
                        <!-- widget product -->
                        <div class="product product-widget">
                            <div class="product-thumb">
                                <img src="{{ asset('storage/img-produk/' . $pt->foto) }}" alt="{{ $pt->nama_produk }}">
                            </div>
                            <div class="product-body">
                                <h2 class="product-name">
                                    <a href="{{ route('produk.detail', $pt->id) }}">{{ $pt->nama_produk }}</a>
                                </h2>
                                <h3 class="product-price">Rp. {{ number_format($pt->harga, 0, ',', '.') }}</h3>
                                <small class="text-muted">{{ $pt->pesanan_detail_count }}x dipesan</small>
                            </div>
                        </div>
                        <!-- /widget product -->
                        @empty
                        <p class="text-muted">Belum ada data penjualan.</p>
                        @endforelse
                    </div>
                    <!-- /aside widget -->
    @endif

                    <!-- aside widget -->
                    <div class="aside">
                        <h3 class="aside-title">Filter Kategori</h3>
                        <ul class="list-links">
                            @php
                            $kategoriSidebar = DB::table('kategori')->orderBy('nama_kategori', 'asc')->get();
                            @endphp
                            @foreach ($kategoriSidebar as $row)
                            <li><a href="{{ route('produk.kategori', $row->id) }}">{{ $row->nama_kategori }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                    <!-- /aside widget -->
                </div>
                <!-- /ASIDE -->

                <!-- MAIN -->
                <div id="main" class="col-md-9">
                    <!-- STORE -->
                    <div id="store">
                        <div class="row">
                            @yield('content')
                            <div class="clearfix visible-md visible-lg visible-sm visible-xs"></div>
                        </div>
                    </div>
                    <!-- /STORE -->
                </div>
                <!-- /MAIN -->
            </div>
        </div>
    </div>
    <!-- /section -->

    <!-- FOOTER -->
    <footer id="footer" class="section section-grey">
        <div class="container">
            <div class="row">
                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <!-- footer logo -->
                        <div class="footer-logo">
                            <a class="logo" href="#">
                                <img src="{{ asset('frontend/img/logo.png') }}" alt="">
                            </a>
                        </div>
                        <!-- /footer logo -->

                        <p>BSI Cyber Store adalah platform belanja online resmi Universitas BSI, menyediakan berbagai
                            produk kebutuhan mahasiswa dan masyarakat umum dengan harga terjangkau dan pengiriman cepat.
                        </p>

                        <!-- footer social -->
                        <ul class="footer-social">
                            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                        </ul>
                        <!-- /footer social -->
                    </div>
                </div>
                <!-- /footer widget -->

                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">Akun Saya</h3>
                        <ul class="list-links">
                            <li><a
                                    href="{{ auth()->check() ? route('customer.akun', ['id' => auth()->id()]) : route('customer.login') }}">Akun
                                    Saya</a></li>
                            <li><a href="{{ route('wishlist') }}">Wishlist Saya</a></li>
                            <li><a href="{{ route('bandingkan') }}">Bandingkan</a></li>
                            <li><a href="{{ route('order.cart') }}">Checkout</a></li>
                        </ul>
                    </div>
                </div>
                <!-- /footer widget -->

                <div class="clearfix visible-sm visible-xs"></div>

                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">Layanan Pelanggan</h3>
                        <ul class="list-links">
                            <li><a href="{{ route('tentang') }}">Tentang Kami</a></li>
                            <li><a href="{{ route('pengiriman') }}">Pengiriman & Pengembalian</a></li>
                            <li><a href="{{ route('panduan-pengiriman') }}">Panduan Pengiriman</a></li>
                            <li><a href="{{ route('kontak') }}">Tanya Jawab</a></li>
                        </ul>
                    </div>
                </div>
                <!-- /footer widget -->

                <!-- footer subscribe -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">Tetap Terhubung</h3>
                        <p>Belanja mudah, aman, dan terpercaya bersama BSI Cyber Store.</p>

                        @if (session('newsletter_success'))
                        <div class="alert alert-success" style="padding:8px;margin-bottom:10px;font-size:13px;">
                            {{ session('newsletter_success') }}
                        </div>
                        @endif
                        @error('email')
                        <div class="alert alert-danger" style="padding:8px;margin-bottom:10px;font-size:13px;">
                            {{ $message }}
                        </div>
                        @enderror

                        <form action="{{ route('newsletter.subscribe') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <input type="email" name="email" class="input" placeholder="Masukkan Alamat Email"
                                    required value="{{ old('email') }}">
                            </div>
                            <button type="submit" class="primary-btn">Berlangganan Newsletter</button>
                        </form>
                    </div>
                </div>
                <!-- /footer subscribe -->
            </div>
            <hr>
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <!-- footer copyright -->
                    <div class="footer-copyright">
                        &copy;<script>
                        document.write(new Date().getFullYear());
                        </script> BSI Cyber Store. All rights reserved
                    </div>
                    <!-- /footer copyright -->
                </div>
            </div>
        </div>
    </footer>
    <!-- /FOOTER -->

    <!-- jQuery Plugins -->
    <script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
    <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('frontend/js/slick.min.js') }}"></script>
    <script src="{{ asset('frontend/js/nouislider.min.js') }}"></script>
    <script src="{{ asset('frontend/js/jquery.zoom.min.js') }}"></script>
    <script src="{{ asset('frontend/js/main.js') }}"></script>

    <!-- Toggle dark/light mode -->
    <script src="{{ asset('js/theme-toggle.js') }}"></script>

    <!-- ===== LIVE CHAT CUSTOMER-ADMIN ===== -->
    @include('frontend.partials.livechat-widget')

    <!-- ===== BAYANGAN HEADER SAAT SCROLL (BARU) ===== -->
    <script>
    (function() {
        const header = document.getElementById('siteHeader');
        if (!header) return;
        const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 10);
        window.addEventListener('scroll', onScroll, {
            passive: true
        });
        onScroll();
    })();
    </script>
    <!-- ===== END BAYANGAN HEADER ===== -->

    <!-- ===== JAM & TANGGAL REAL-TIME (CUSTOMER) ===== -->
    <script>
    (function() {
        const jamEl = document.getElementById('jamRealtimeCustomer');
        const tglEl = document.getElementById('tanggalRealtimeCustomer');
        if (!jamEl || !tglEl) return;

        const hariList = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', "Jum'at", 'Sabtu'];
        const bulanList = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
            'Oktober', 'November', 'Desember'
        ];

        function updateJam() {
            const now = new Date();
            const jam = String(now.getHours()).padStart(2, '0');
            const menit = String(now.getMinutes()).padStart(2, '0');
            const detik = String(now.getSeconds()).padStart(2, '0');
            jamEl.textContent = `${jam}:${menit}:${detik}`;
            tglEl.textContent =
                `${hariList[now.getDay()]}, ${now.getDate()} ${bulanList[now.getMonth()]} ${now.getFullYear()}`;
        }

        updateJam();
        setInterval(updateJam, 1000);
    })();
    </script>
    <!-- ===== END JAM REAL-TIME ===== -->

    @auth
    <!-- ===== NOTIFIKASI REAL-TIME ===== -->
    <script>
    (function() {
        const badge = document.getElementById('notifBadge');
        const list = document.getElementById('notifList');
        if (!badge || !list) return;

        const STORAGE_KEY = 'notifSeenIds_{{ auth()->id() }}';

        function escapeHtml(str) {
            const div = document.createElement('div');
            div.textContent = str ?? '';
            return div.innerHTML;
        }

        function getSeenIds() {
            try {
                return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
            } catch (e) {
                return [];
            }
        }

        function saveSeenIds(ids) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
        }

        function loadNotif(markAsRead = false) {
            fetch("{{ route('backend.notifikasi') }}", {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    const orders = data.orders || [];
                    const users = data.users || [];

                    const orderTags = orders.map(o => 'order-' + o.id + '-' + o.status);
                    const userTags = users.map(u => 'user-' + u.email + '-' + u.waktu);
                    const allTags = [...orderTags, ...userTags];

                    const seenBefore = getSeenIds();
                    const unseenCount = allTags.filter(tag => !seenBefore.includes(tag)).length;

                    if (unseenCount > 0) {
                        badge.style.display = 'inline-block';
                        badge.textContent = unseenCount;
                    } else {
                        badge.style.display = 'none';
                    }

                    let html = '';

                    orders.forEach((o, idx) => {
                        const href = o.link ? escapeHtml(o.link) : '#';
                        const isUnread = !seenBefore.includes(orderTags[idx]);
                        html += `
                                    <li>
                                        <a href="${href}" class="notif-item ${isUnread ? 'notif-unread' : ''}">
                                            <span class="notif-dot"></span>
                                            <div class="notif-title">📦 ${escapeHtml(o.kode_pesanan)} &middot; ${escapeHtml(o.status)}</div>
                                            <div class="notif-sub">${escapeHtml(o.customer_name)} &bull; ${escapeHtml(o.total_format)}</div>
                                            <div class="notif-time">${escapeHtml(o.waktu)}</div>
                                        </a>
                                    </li>`;
                    });

                    users.forEach((u, idx) => {
                        const isUnread = !seenBefore.includes(userTags[idx]);
                        html += `
                                    <li class="notif-item ${isUnread ? 'notif-unread' : ''}">
                                        <span class="notif-dot"></span>
                                        <div class="notif-title">👤 ${escapeHtml(u.nama)} (${escapeHtml(u.role)})</div>
                                        <div class="notif-time">${escapeHtml(u.waktu)}</div>
                                    </li>`;
                    });

                    list.innerHTML = html || '<div class="notif-empty">Tidak ada notifikasi baru</div>';

                    if (markAsRead) {
                        saveSeenIds(allTags);
                    }
                })
                .catch(() => {
                    list.innerHTML = '<div class="notif-error">Gagal memuat notifikasi</div>';
                });
        }

        document.querySelector('.header-notif .dropdown-toggle')?.addEventListener('click', () => loadNotif(true));

        loadNotif(false);
        setInterval(() => loadNotif(false), 30000);
    })();
    </script>
    <!-- ===== END NOTIFIKASI ===== -->
    @endauth

    @auth
    @if (session('welcome_shown') !== Auth::id())
    @php session(['welcome_shown' => Auth::id()]); @endphp
    <!-- ===== TOAST SELAMAT DATANG ===== -->
    <div id="bsiToast" class="bsi-toast" role="alert">
        <div class="bsi-toast-icon">👋</div>
        <div class="bsi-toast-text">
            Halo, selamat datang <strong>{{ Auth::user()->nama }}</strong> di BSI Cyber Store
        </div>
        <button type="button" class="bsi-toast-close" id="bsiToastClose" aria-label="Tutup">&times;</button>
    </div>
    <script>
    (function() {
        const toast = document.getElementById('bsiToast');
        const closeBtn = document.getElementById('bsiToastClose');
        if (!toast) return;

        function hide() {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 500);
        }

        requestAnimationFrame(() => setTimeout(() => toast.classList.add('show'), 100));
        const timer = setTimeout(hide, 5000);

        closeBtn.addEventListener('click', function() {
            clearTimeout(timer);
            hide();
        });
    })();
    </script>
    <!-- ===== END TOAST SELAMAT DATANG ===== -->
    @endif
    @endauth

    <!-- ===== IKON HAMBURGER JADI X (nav-icon-final) ===== -->
    <style>
    .nav-toggle-btn i, .menu-header i { display: inline-block; transition: transform .3s ease; }
    .is-x i { transform: rotate(180deg); }
    </style>
    <script>
    (function() {
        var btn = document.querySelector('.nav-toggle-btn');
        var head = document.querySelector('.menu-nav .menu-header');
        var state = false;

        function paint(on) {
            state = on;
            [btn, head].forEach(function(el) {
                if (!el) return;
                var i = el.querySelector('i');
                if (!i) return;
                el.classList.toggle('is-x', on);
                i.classList.toggle('fa-bars', !on);
                i.classList.toggle('fa-times', on);
            });
        }

        paint(false);

        if (btn) btn.addEventListener('click', function() { paint(!state); });
        if (head) head.addEventListener('click', function() { paint(!state); });

        // layar diperlebar: menu mobile hilang, ikon kembali ke hamburger
        window.addEventListener('resize', function() {
            if (window.innerWidth > 991 && state) paint(false);
        });
    })();
    </script>
    <!-- ===== END IKON HAMBURGER JADI X ===== -->
</body>

</html>