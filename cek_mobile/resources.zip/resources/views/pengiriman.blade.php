﻿@extends('v_layouts.app')

@section('judul', 'Pengiriman & Pengembalian')

@section('content')
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
:root {
    --ink: #1E2A3A;
    --ink-soft: #5B6472;
    --blue: #1976D2;
    --coral: #E85D3D;
    --green: #1E8E5A;
    --paper: #FBFAF8;
    --line: #E4E7ED;
}

.pk-wrapper {
    background: var(--paper);
    color: var(--ink);
    font-family: 'Plus Jakarta Sans', sans-serif;
    line-height: 1.6;
}

.pk-container {
    max-width: 1080px;
    margin: 0 auto;
    padding: 0 24px;
}

.pk-serif {
    font-family: 'Fraunces', serif;
}

.pk-hero {
    padding: 72px 0 40px;
    border-bottom: 1px solid var(--line);
}

.pk-hero h1 {
    font-size: 40px;
    font-weight: 500;
    line-height: 1.2;
    margin: 0 0 18px;
    max-width: 20ch;
}

.pk-hero p {
    font-size: 16px;
    color: var(--ink-soft);
    max-width: 56ch;
    margin: 0 0 32px;
}

.pk-facts {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.pk-fact {
    display: flex;
    align-items: center;
    gap: 9px;
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 30px;
    padding: 9px 16px 9px 12px;
    font-size: 13.5px;
    font-weight: 600;
}

.pk-fact i {
    color: var(--coral);
    font-size: 13px;
}

.pk-section {
    padding: 56px 0;
    border-bottom: 1px solid var(--line);
}

.pk-section h2 {
    font-size: 27px;
    font-weight: 500;
    margin: 0 0 8px;
}

.pk-section .pk-lede {
    font-size: 14.5px;
    color: var(--ink-soft);
    max-width: 62ch;
    margin: 0 0 32px;
}

.pk-ekspedisi-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}

.pk-ekspedisi-chip {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 16px 14px;
    background: #fff;
}

.pk-ekspedisi-chip .nm {
    font-weight: 700;
    font-size: 14px;
    margin-bottom: 3px;
}

.pk-ekspedisi-chip .ket {
    font-size: 12px;
    color: var(--ink-soft);
}

.pk-flow {
    display: flex;
    gap: 0;
}

.pk-flow-step {
    flex: 1;
    position: relative;
    padding: 24px 20px 0 0;
}

.pk-flow-step:not(:last-child)::after {
    content: '';
    position: absolute;
    top: 11px;
    right: 0;
    width: 100%;
    height: 2px;
    background: var(--line);
}

.pk-flow-num {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: var(--ink);
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    z-index: 1;
    margin-bottom: 16px;
}

.pk-flow-step h4 {
    font-size: 14.5px;
    font-weight: 700;
    margin: 0 0 6px;
}

.pk-flow-step p {
    font-size: 13px;
    color: var(--ink-soft);
    margin: 0;
    max-width: 24ch;
}

.pk-kondisi-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
    margin-bottom: 40px;
}

.pk-kondisi-box {
    border-radius: 12px;
    padding: 22px 24px;
}

.pk-kondisi-box.bisa {
    background: #F0F9F4;
    border: 1px solid #CFE9DA;
}

.pk-kondisi-box.tidak {
    background: #FBF1EE;
    border: 1px solid #F0D9D1;
}

.pk-kondisi-box h4 {
    font-size: 14.5px;
    font-weight: 700;
    margin: 0 0 12px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.pk-kondisi-box.bisa h4 { color: var(--green); }
.pk-kondisi-box.tidak h4 { color: var(--coral); }

.pk-kondisi-box ul {
    margin: 0;
    padding-left: 18px;
}

.pk-kondisi-box li {
    font-size: 13.5px;
    color: var(--ink-soft);
    margin-bottom: 6px;
}

.pk-langkah {
    list-style: none;
    margin: 0;
    padding: 0;
    counter-reset: langkah;
}

.pk-langkah li {
    counter-increment: langkah;
    display: flex;
    gap: 18px;
    padding: 18px 0;
    border-top: 1px solid var(--line);
}

.pk-langkah li:first-child {
    border-top: none;
}

.pk-langkah li::before {
    content: counter(langkah);
    flex-shrink: 0;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 1.5px solid var(--ink);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 700;
}

.pk-langkah h4 {
    font-size: 14.5px;
    font-weight: 700;
    margin: 0 0 4px;
}

.pk-langkah p {
    font-size: 13.5px;
    color: var(--ink-soft);
    margin: 0;
}

.pk-refund-note {
    display: flex;
    gap: 16px;
    background: #F3F6FB;
    border: 1px solid #D9E4F3;
    border-radius: 12px;
    padding: 20px 22px;
    margin-top: 28px;
}

.pk-refund-note i {
    color: var(--blue);
    font-size: 18px;
    margin-top: 2px;
}

.pk-refund-note h4 {
    font-size: 14px;
    font-weight: 700;
    margin: 0 0 4px;
}

.pk-refund-note p {
    font-size: 13.5px;
    color: var(--ink-soft);
    margin: 0;
}

.pk-faq details {
    border-top: 1px solid var(--line);
    padding: 16px 0;
}

.pk-faq details:last-child {
    border-bottom: 1px solid var(--line);
}

.pk-faq summary {
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.pk-faq summary::-webkit-details-marker {
    display: none;
}

.pk-faq summary::after {
    content: '+';
    font-size: 20px;
    color: var(--ink-soft);
    font-weight: 400;
    flex-shrink: 0;
    margin-left: 16px;
}

.pk-faq details[open] summary::after {
    content: '−';
}

.pk-faq details p {
    font-size: 13.5px;
    color: var(--ink-soft);
    margin: 12px 0 0;
    max-width: 66ch;
}

.pk-cta {
    background: var(--ink);
    padding: 56px 0;
    text-align: center;
}

.pk-cta h2 {
    font-family: 'Fraunces', serif;
    color: #fff;
    font-size: 28px;
    font-weight: 500;
    margin: 0 0 10px;
}

.pk-cta p {
    color: rgba(255,255,255,.7);
    font-size: 14px;
    margin: 0 0 24px;
}

.btn-pk-primary {
    background: var(--coral);
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 13px 26px;
    font-weight: 600;
    font-size: 14.5px;
    text-decoration: none;
    display: inline-block;
}

.btn-pk-primary:hover {
    background: #cf4c30;
    color: #fff;
}

@media (max-width: 800px) {
    .pk-hero h1 { font-size: 30px; }
    .pk-ekspedisi-grid { grid-template-columns: repeat(2, 1fr); }
    .pk-flow { flex-direction: column; gap: 20px; }
    .pk-flow-step { padding: 0 0 0 0; }
    .pk-flow-step::after { display: none; }
    .pk-kondisi-grid { grid-template-columns: 1fr; }
}
</style>

<div class="pk-wrapper" style="max-height: 75vh; overflow-y: auto;">
    <div class="pk-container">

        <div class="pk-hero">
            <h1 class="pk-serif">Kapan sampai, dan gimana kalau nggak sesuai — semua ada di sini.</h1>
            <p>Nggak perlu tanya-tanya dulu ke admin. Semua soal ongkir, estimasi waktu kirim, sampai cara retur kalau barangnya bermasalah, kami jelasin lengkap di bawah.</p>
            <div class="pk-facts">
                <div class="pk-fact"><i class="fas fa-box"></i> Diproses &lt; 24 jam</div>
                <div class="pk-fact"><i class="fas fa-truck-fast"></i> 8 pilihan ekspedisi</div>
                <div class="pk-fact"><i class="fas fa-rotate-left"></i> Retur maks. 2x24 jam</div>
                <div class="pk-fact"><i class="fas fa-money-bill-wave"></i> Refund 3–5 hari kerja</div>
            </div>
        </div>

        <div class="pk-section">
            <h2 class="pk-serif">Ekspedisi yang kami pakai</h2>
            <p class="pk-lede">Kamu bisa pilih sendiri ekspedisinya saat checkout, sesuai yang paling cepat atau paling murah buat daerah kamu.</p>
            <div class="pk-ekspedisi-grid">
                <div class="pk-ekspedisi-chip"><div class="nm">JNE</div><div class="ket">Reguler & YES</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">J&amp;T Express</div><div class="ket">Reguler & EZ</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">SiCepat</div><div class="ket">Reguler & BEST</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">Anteraja</div><div class="ket">Reguler</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">POS Indonesia</div><div class="ket">Kilat Khusus</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">TIKI</div><div class="ket">Reguler & ONS</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">Ninja Xpress</div><div class="ket">Reguler</div></div>
                <div class="pk-ekspedisi-chip"><div class="nm">SAP Express</div><div class="ket">Reguler</div></div>
            </div>
        </div>

        <div class="pk-section">
            <h2 class="pk-serif">Alur pesanan kamu</h2>
            <p class="pk-lede">Dari bayar sampai barang di tangan kamu, semua bisa dipantau langsung dari halaman Riwayat Belanja — nggak perlu tanya ke mana-mana.</p>
            <div class="pk-flow">
                <div class="pk-flow-step">
                    <div class="pk-flow-num">1</div>
                    <h4>Pembayaran dikonfirmasi</h4>
                    <p>Status pesanan berubah otomatis begitu pembayaran masuk.</p>
                </div>
                <div class="pk-flow-step">
                    <div class="pk-flow-num">2</div>
                    <h4>Dikemas</h4>
                    <p>Barang disiapkan dan dikemas, biasanya di hari yang sama.</p>
                </div>
                <div class="pk-flow-step">
                    <div class="pk-flow-num">3</div>
                    <h4>Dikirim</h4>
                    <p>Nomor resi muncul di Riwayat Belanja, langsung bisa dilacak.</p>
                </div>
                <div class="pk-flow-step">
                    <div class="pk-flow-num">4</div>
                    <h4>Sampai</h4>
                    <p>Cek barangnya begitu diterima, sebelum kurir pergi kalau bisa.</p>
                </div>
            </div>
        </div>

        <div class="pk-section">
            <h2 class="pk-serif">Kalau barangnya bermasalah</h2>
            <p class="pk-lede">Retur bisa diajukan maksimal 2x24 jam setelah barang diterima. Beberapa jenis produk memang nggak bisa diretur — ini rinciannya.</p>

            <div class="pk-kondisi-grid">
                <div class="pk-kondisi-box bisa">
                    <h4><i class="fas fa-circle-check"></i> Bisa diretur</h4>
                    <ul>
                        <li>Barang rusak atau cacat saat diterima</li>
                        <li>Barang yang dikirim salah dari pesanan</li>
                        <li>Jumlah barang tidak sesuai pesanan</li>
                        <li>Produk elektronik (HP, laptop) tidak menyala/bermasalah</li>
                    </ul>
                </div>
                <div class="pk-kondisi-box tidak">
                    <h4><i class="fas fa-circle-xmark"></i> Tidak bisa diretur</h4>
                    <ul>
                        <li>Makanan dan minuman yang sudah diterima dalam kondisi baik</li>
                        <li>Kesalahan pemilihan ukuran/warna dari pihak pembeli</li>
                        <li>Barang sudah dipakai atau kemasan sudah dibuka (di luar kondisi cacat)</li>
                        <li>Pengajuan lewat dari 2x24 jam sejak barang diterima</li>
                    </ul>
                </div>
            </div>

            <ol class="pk-langkah">
                <li>
                    <div>
                        <h4>Hubungi kami dengan bukti</h4>
                        <p>Buka halaman Riwayat Belanja, pilih pesanan yang bermasalah, lalu hubungi kami lewat halaman Hubungi Kami. Sertakan foto atau video kondisi barang.</p>
                    </div>
                </li>
                <li>
                    <div>
                        <h4>Verifikasi</h4>
                        <p>Kami cek laporan kamu, biasanya dibalas dalam 1x24 jam kerja.</p>
                    </div>
                </li>
                <li>
                    <div>
                        <h4>Kirim balik (jika diminta)</h4>
                        <p>Untuk kasus tertentu, barang perlu dikirim balik dulu. Ongkos kirim retur ditanggung kami kalau memang kesalahan dari pihak toko.</p>
                    </div>
                </li>
                <li>
                    <div>
                        <h4>Refund atau tukar barang</h4>
                        <p>Setelah diverifikasi, kamu bisa pilih dana dikembalikan atau barang diganti dengan yang baru.</p>
                    </div>
                </li>
            </ol>

            <div class="pk-refund-note">
                <i class="fas fa-circle-info"></i>
                <div>
                    <h4>Soal dana refund</h4>
                    <p>Dana dikembalikan ke metode pembayaran awal, diproses 3–5 hari kerja setelah retur disetujui. Untuk pembayaran lewat transfer, mohon siapkan nomor rekening tujuan saat dihubungi tim kami.</p>
                </div>
            </div>
        </div>

        <div class="pk-section" style="border-bottom: none;">
            <h2 class="pk-serif">Yang sering ditanyakan</h2>
            <div class="pk-faq">
                <details>
                    <summary>Berapa lama pesanan sampai?</summary>
                    <p>Rata-rata 1–2 hari kerja untuk area dalam kota, 2–4 hari untuk luar kota, dan 4–7 hari untuk luar pulau. Estimasi pastinya muncul saat kamu cek ongkir di halaman checkout.</p>
                </details>
                <details>
                    <summary>Bisa ganti alamat pengiriman setelah checkout?</summary>
                    <p>Bisa, selama status pesanan masih "Menunggu Pembayaran" atau belum masuk tahap dikemas. Hubungi kami secepatnya lewat halaman Hubungi Kami.</p>
                </details>
                <details>
                    <summary>Kenapa nomor resi belum muncul?</summary>
                    <p>Nomor resi biasanya muncul di Riwayat Belanja begitu status berubah jadi "Dikirim". Kalau sudah lebih dari 2 hari sejak pembayaran dan belum muncul juga, hubungi kami.</p>
                </details>
                <details>
                    <summary>Ongkir dihitung berdasarkan apa?</summary>
                    <p>Berdasarkan berat produk dan jarak dari gudang kami ke alamat kamu, dihitung otomatis lewat fitur cek ongkir sebelum kamu bayar — jadi nggak ada biaya kejutan.</p>
                </details>
                <details>
                    <summary>Apakah bisa COD (bayar di tempat)?</summary>
                    <p>Saat ini kami hanya melayani pembayaran non-tunai lewat metode yang tersedia di halaman checkout, belum menyediakan COD.</p>
                </details>
            </div>
        </div>

    </div>

    <div class="pk-cta">
        <h2>Masih ada yang mau ditanyakan?</h2>
        <p>Tim kami siap bantu lewat halaman kontak atau chatbot di pojok layar.</p>
        <a href="{{ route('kontak') }}" class="btn-pk-primary">Hubungi Kami</a>
    </div>
</div>

@endsection

