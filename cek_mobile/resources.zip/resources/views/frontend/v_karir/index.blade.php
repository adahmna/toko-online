@extends('v_layouts.app')

@section('judul', $judul)

@section('content')
<div class="col-md-12">

    @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <h2 style="margin-bottom:5px;">Karir di BSI Cyber Store</h2>
    <p class="text-muted" style="margin-bottom:25px;">
        Bergabunglah bersama tim kami dan kembangkan kariermu di dunia teknologi.
    </p>

    <h3>Kenapa Bergabung dengan Kami?</h3>
    <ul style="margin-bottom:20px;">
        <li>Lingkungan kerja yang suportif dan kolaboratif</li>
        <li>Kesempatan belajar dan berkembang</li>
        <li>Jenjang karir yang jelas</li>
    </ul>

    <h3>Cara Melamar</h3>
    <p style="margin-bottom:25px;">
        Isi formulir lamaran dengan data diri lengkap dan lampirkan CV dalam format PDF
        (maksimal 2MB). Tim HRD kami akan meninjau lamaranmu dan menghubungi via email
        jika lolos seleksi awal.
    </p>

    <a href="{{ route('karir.lamar') }}" class="primary-btn">Lamar Sekarang</a>

</div>
@endsection