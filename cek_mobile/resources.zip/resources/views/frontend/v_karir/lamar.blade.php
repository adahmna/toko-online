@extends('v_layouts.karir')

@section('judul', $judul)

@section('content')
<div class="col-md-12">

    <style>
    .lamar-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 40px;
        align-items: center;
        padding: 30px 10px 50px;
    }

    .lamar-ilustrasi {
        flex: 1 1 380px;
        display: flex;
        justify-content: center;
        align-items: center;
        min-width: 300px;
    }

    .lamar-ilustrasi svg {
        width: 100%;
        max-width: 380px;
        animation: floatUpDown 3.5s ease-in-out infinite;
    }

    @keyframes floatUpDown {

        0%,
        100% {
            transform: translateY(0px);
        }

        50% {
            transform: translateY(-16px);
        }
    }

    .lamar-orbit {
        transform-origin: center;
        animation: spinSlow 12s linear infinite;
    }

    @keyframes spinSlow {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }

    .lamar-form-box {
        flex: 1 1 420px;
        min-width: 300px;
        background: #fff;
        border-radius: 14px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        padding: 32px 30px;
    }

    .lamar-form-box h2 {
        margin-bottom: 6px;
        font-weight: 700;
    }

    .lamar-subtitle {
        color: #777;
        margin-bottom: 24px;
        font-size: 14px;
    }

    .lamar-field {
        opacity: 0;
        transform: translateY(16px);
        animation: fadeUp 0.5s ease forwards;
    }

    .lamar-field:nth-child(1) {
        animation-delay: 0.05s;
    }

    .lamar-field:nth-child(2) {
        animation-delay: 0.15s;
    }

    .lamar-field:nth-child(3) {
        animation-delay: 0.25s;
    }

    .lamar-field:nth-child(4) {
        animation-delay: 0.35s;
    }

    .lamar-field:nth-child(5) {
        animation-delay: 0.45s;
    }

    .lamar-field:nth-child(6) {
        animation-delay: 0.55s;
    }

    @keyframes fadeUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .lamar-form-box .form-group {
        margin-bottom: 18px;
    }

    .lamar-form-box label {
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 6px;
        display: block;
    }

    .lamar-form-box .input,
    .lamar-form-box textarea {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px 12px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .lamar-form-box .input:focus,
    .lamar-form-box textarea:focus {
        border-color: #ff6600;
        box-shadow: 0 0 0 3px rgba(255, 102, 0, 0.12);
        outline: none;
    }

    .lamar-btn-row {
        display: flex;
        gap: 10px;
        margin-top: 10px;
    }

    .lamar-btn-row .primary-btn {
        border-radius: 8px;
        transition: transform 0.15s ease;
    }

    .lamar-btn-row .primary-btn:hover {
        transform: translateY(-2px);
    }

    @media (max-width: 767px) {
        .lamar-wrapper {
            padding: 15px 5px 30px;
        }
    }
    </style>

    @if($errors->any())
    <div class="alert alert-danger" style="margin: 20px 10px 0;">
        <ul style="margin-bottom:0;">
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <div class="lamar-wrapper">

        {{-- Ilustrasi kiri --}}
        <div class="lamar-ilustrasi">
            <svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
                <circle class="lamar-orbit" cx="200" cy="200" r="150" fill="none" stroke="#ffe0c2" stroke-width="2"
                    stroke-dasharray="8 10" />
                <circle cx="200" cy="140" r="55" fill="#ffe8d6" />
                <rect x="120" y="190" width="160" height="120" rx="16" fill="#ff6600" />
                <rect x="140" y="210" width="120" height="14" rx="7" fill="#ffffff" opacity="0.85" />
                <rect x="140" y="234" width="90" height="10" rx="5" fill="#ffffff" opacity="0.6" />
                <rect x="140" y="252" width="100" height="10" rx="5" fill="#ffffff" opacity="0.6" />
                <circle cx="200" cy="130" r="30" fill="#2b2b2b" />
                <rect x="178" y="150" width="44" height="10" rx="5" fill="#2b2b2b" />
                <rect x="160" y="290" width="80" height="16" rx="8" fill="#333333" opacity="0.15" />
                <path d="M320 90 l10 10 l-10 10 l-10 -10 Z" fill="#ff6600" opacity="0.5" />
                <path d="M60 300 l8 8 l-8 8 l-8 -8 Z" fill="#ff6600" opacity="0.4" />
                <circle cx="330" cy="260" r="6" fill="#ffb066" />
                <circle cx="55" cy="150" r="5" fill="#ffb066" />
            </svg>
        </div>

        {{-- Form kanan --}}
        <div class="lamar-form-box">
            <h2>Form Lamaran Kerja</h2>
            <p class="lamar-subtitle">Isi data di bawah ini untuk melamar posisi yang tersedia di BSI Cyber Store.</p>

            <form action="{{ route('karir.proses-lamar') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="form-group lamar-field">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama" class="input" style="width:100%;" value="{{ old('nama') }}" required>
                </div>

                <div class="form-group lamar-field">
                    <label>Email</label>
                    <input type="email" name="email" class="input" style="width:100%;" value="{{ old('email') }}"
                        required>
                </div>

                <div class="form-group lamar-field">
                    <label>No. HP</label>
                    <input type="text" name="hp" class="input" style="width:100%;" value="{{ old('hp') }}"
                        placeholder="Contoh: 081234567890" required>
                </div>

                <div class="form-group lamar-field">
                    <label>Alasan Melamar</label>
                    <textarea name="alasan" rows="4" class="input" style="width:100%;" placeholder="Minimal 20 karakter"
                        required>{{ old('alasan') }}</textarea>
                </div>

                <div class="form-group lamar-field">
                    <label>Upload CV (PDF, maks 2MB)</label><br>
                    <input type="file" name="cv" accept="application/pdf" required>
                </div>

                <div class="lamar-btn-row lamar-field">
                    <a href="{{ route('karir.index') }}" class="primary-btn" style="background:#777;">Kembali</a>
                    <button type="submit" class="primary-btn">Kirim Lamaran</button>
                </div>
            </form>
        </div>

    </div>

</div>
@endsection