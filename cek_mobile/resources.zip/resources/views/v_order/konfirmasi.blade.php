@extends('v_layouts.app')
@section('content')
<div class="col-md-12">
    <div class="order-summary clearfix">
        <div class="section-title">
            <p>RINGKASAN</p>
            <h3 class="title">Keranjang Belanja</h3>
        </div>

        <table class="shopping-cart-table table">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th class="text-center">Harga</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($order->orderItems as $item)
                <tr>
                    <td class="details">
                        <a>{{ $item->produk->nama_produk }}</a>
                        <ul>
                            <li><span>Berat: {{ $item->produk->berat }} Gram</span></li>
                        </ul>
                        <ul>
                            <li><span>Stok: {{ $item->produk->stok }} Gram</span></li>
                        </ul>
                    </td>
                    <td class="price text-center">
                        <strong>Rp. {{ number_format($item->harga, 0, ',', '.') }}</strong>
                    </td>
                    <td class="qty text-center">{{ $item->jumlah }}</td>
                    <td class="total text-center">
                        <strong class="primary-color">
                            Rp. {{ number_format($item->harga * $item->jumlah, 0, ',', '.') }}
                        </strong>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="row justify-content-end" style="margin-top:15px;">
            <div class="col-md-5">
                <table class="table">
                    <tbody>
                        <tr>
                            <td>Subtotal</td>
                            <td class="text-right"><strong>Rp. {{ number_format($subtotal, 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td>Ongkos Kirim</td>
                            <td class="text-right">
                                <div>Rp. {{ number_format($ongkir, 0, ',', '.') }}</div>
                                <small class="text-muted">
                                    {{ strtolower($ekspedisi) }}.{{ $layanan }}
                                    @if($estimasi) *estimasi {{ $estimasi }} @endif
                                </small>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Total Bayar</strong></td>
                            <td class="text-right"><strong class="primary-color" style="font-size:18px;">
                                    Rp. {{ number_format($total, 0, ',', '.') }}
                                </strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Form ini yang benar-benar menyimpan pesanan lalu lanjut ke halaman pembayaran (timer) --}}
        <form action="{{ route('order.pilihPengiriman') }}" method="POST" id="form-bayar">
            @csrf
            <input type="hidden" name="kota_tujuan" value="{{ $kota_tujuan }}">
            <input type="hidden" name="id_kota_tujuan" value="{{ $id_kota_tujuan }}">
            <input type="hidden" name="ekspedisi" value="{{ $ekspedisi }}">
            <input type="hidden" name="layanan" value="{{ $layanan }}">
            <input type="hidden" name="ongkir" value="{{ $ongkir }}">
            <input type="hidden" name="alamat" value="{{ $alamat }}">
            <input type="hidden" name="kode_pos" value="{{ $kode_pos }}">

            <div class="pull-right" style="margin-top:15px;">
                <button type="submit" class="primary-btn" id="btn-bayar">Bayar Sekarang</button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('form-bayar').addEventListener('submit', function() {
    const btn = document.getElementById('btn-bayar');
    btn.disabled = true;
    btn.innerText = 'Memproses...';
});
</script>
@endsection
