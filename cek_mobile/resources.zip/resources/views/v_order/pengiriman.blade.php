@extends('v_layouts.app')
@section('content')
<meta name="total-harga" content="{{ $totalHarga }}">
<meta name="total-berat" content="{{ $totalBerat }}">
<div class="col-md-12">
    <div class="order-summary clearfix">
        <div class="section-title">
            <p>PENGIRIMAN</p>
            <h3 class="title">Pilih Pengiriman</h3>
        </div>

        <p><strong>Total Berat:</strong> {{ $totalBerat }} Gram</p>

        <div class="form-group">
            <label>Provinsi Tujuan</label>
            <select id="province" class="form-control">
                <option value="">Pilih Provinsi</option>
            </select>
        </div>

        <div class="form-group">
            <label>Kota/Kabupaten Tujuan</label>
            <select id="city" class="form-control">
                <option value="">Pilih Kota</option>
            </select>
        </div>

        <div class="form-group">
            <label>Kurir</label>
            <select id="courier" class="form-control">
                <option value="">Pilih Kurir</option>
                <option value="jne">JNE</option>
                <option value="tiki">TIKI</option>
                <option value="pos">POS Indonesia</option>
                <option value="jnt">J&T Express</option>
                <option value="sicepat">SiCepat</option>
            </select>
        </div>

        <div class="form-group">
            <label>Alamat</label>
            <textarea id="alamat" class="form-control" rows="3"
                placeholder="Contoh: Jl. Sawo No. 4 RT/RW 09/10"></textarea>
        </div>

        <div class="form-group">
            <label>Kode Pos</label>
            <input type="text" id="kode_pos" class="form-control" placeholder="Contoh: 52114">
        </div>

        <button type="button" id="btnCekOngkir" class="btn btn-secondary">Cek Ongkir</button>

        <div id="resultOngkir" style="margin-top:20px;"></div>

        {{-- Form ini yang benar-benar dikirim saat salah satu tombol "Pilih Pengiriman" diklik --}}
        <form id="pilihForm" action="{{ route('order.konfirmasi') }}" method="POST">
            @csrf
            <input type="hidden" name="kota_tujuan" id="kota_tujuan_input">
            <input type="hidden" name="id_kota_tujuan" id="id_kota_tujuan_input">
            <input type="hidden" name="ekspedisi" id="ekspedisi_input">
            <input type="hidden" name="layanan" id="layanan_input">
            <input type="hidden" name="ongkir" id="ongkir_input">
            <input type="hidden" name="estimasi" id="estimasi_input">
            <input type="hidden" name="alamat" id="alamat_input">
            <input type="hidden" name="kode_pos" id="kode_pos_input">
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const originCityId = '3275'; // GANTI dengan ID kota asal toko kamu (cek lewat /cities)
    const totalHarga = Number(document.querySelector('meta[name="total-harga"]').content);

    // Ambil data provinsi (format emsifa: array langsung, field "id" & "name")
    fetch('/provinces')
        .then(r => r.json())
        .then(data => {
            if (Array.isArray(data)) {
                const sel = document.getElementById('province');
                data.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p.id;
                    opt.textContent = p.name;
                    sel.appendChild(opt);
                });
            } else {
                console.error('Failed to fetch provinces', data);
            }
        })
        .catch(error => console.error('Error fetching provinces:', error));

    document.getElementById('province').addEventListener('change', function() {
        const citySel = document.getElementById('city');
        citySel.innerHTML = '<option value="">Pilih Kota</option>';
        if (!this.value) return;

        // Ambil data kota (format emsifa: array langsung, field "id" & "name")
        fetch(`/cities?province_id=${this.value}`)
            .then(r => r.json())
            .then(data => {
                if (Array.isArray(data)) {
                    data.forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c.id;
                        opt.textContent = c.name;
                        citySel.appendChild(opt);
                    });
                } else {
                    console.error('Failed to fetch cities', data);
                }
            })
            .catch(error => console.error('Error fetching cities:', error));
    });

    document.getElementById('btnCekOngkir').addEventListener('click', function() {
        const cityId = document.getElementById('city').value;
        const cityName = document.getElementById('city').selectedOptions[0]?.textContent;
        const courier = document.getElementById('courier').value;
        const alamat = document.getElementById('alamat').value.trim();
        const kodePos = document.getElementById('kode_pos').value.trim();
        const weight = Number(document.querySelector('meta[name="total-berat"]').content);

        if (!cityId || !courier) {
            alert('Pilih kota tujuan dan kurir terlebih dahulu.');
            return;
        }
        if (!alamat || !kodePos) {
            alert('Isi alamat dan kode pos terlebih dahulu.');
            return;
        }

        fetch('/cost', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute(
                        'content') || '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    origin: originCityId,
                    destination: cityId,
                    weight: weight,
                    courier: courier
                })
            })
            .then(r => r.json())
            .then(data => {
                const resultDiv = document.getElementById('resultOngkir');
                resultDiv.innerHTML = '';

                if (data.status === 200 && data.data && data.data.costs) {
                    const table = document.createElement('table');
                    table.className = 'table table-bordered';
                    table.innerHTML = `
                        <thead>
                            <tr>
                                <th>Layanan</th>
                                <th>Biaya</th>
                                <th>Estimasi Pengiriman</th>
                                <th>Total Berat</th>
                                <th>Total Harga</th>
                                <th>Bayar</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    `;
                    const tbody = table.querySelector('tbody');

                    data.data.costs.forEach(cost => {
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td>${cost.service}</td>
                            <td>Rp ${Number(cost.price).toLocaleString('id-ID')}</td>
                            <td>${cost.estimated}</td>
                            <td>${weight} Gram</td>
                            <td>Rp ${Number(totalHarga).toLocaleString('id-ID')}</td>
                            <td>
                                <button type="button" class="btn btn-sm btn-primary btn-pilih-pengiriman">
                                    Pilih Pengiriman
                                </button>
                            </td>
                        `;
                        tr.querySelector('.btn-pilih-pengiriman').addEventListener('click',
                            function() {
                                document.getElementById('kota_tujuan_input').value =
                                    cityName;
                                document.getElementById('id_kota_tujuan_input').value =
                                    cityId;
                                document.getElementById('ekspedisi_input').value =
                                    courier;
                                document.getElementById('layanan_input').value = cost
                                    .service;
                                document.getElementById('ongkir_input').value = cost
                                    .price;
                                document.getElementById('estimasi_input').value = cost
                                    .estimated;
                                document.getElementById('alamat_input').value = alamat;
                                document.getElementById('kode_pos_input').value =
                                    kodePos;

                                document.getElementById('pilihForm').submit();
                            });
                        tbody.appendChild(tr);
                    });

                    resultDiv.appendChild(table);
                } else {
                    resultDiv.textContent = data.message ??
                        'Ongkir tidak ditemukan untuk rute ini.';
                }
            })
            .catch(() => {
                document.getElementById('resultOngkir').textContent =
                    'Gagal mengambil data ongkir.';
            });
    });
});
</script>
@endsection