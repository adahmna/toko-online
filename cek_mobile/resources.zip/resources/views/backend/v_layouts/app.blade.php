<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link class="rounded-circle" rel="icon" type="image/png" sizes="16x16"
        href="{{ asset('image/icon_univ_bsi.png') }}">
    <title>tokoonline</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('backend/extra-libs/multicheck/multicheck.css') }}">
    <link href="{{ asset('backend/libs/datatables.net-bs4/css/dataTables.bootstrap4.css') }}" rel="stylesheet">
    <link href="{{ asset('backend/dist/css/style.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    .notif-bell-wrapper {
        position: relative;
        display: inline-block;
    }

    .notif-badge {
        position: absolute;
        top: -4px;
        right: -6px;
        background: #ef5350;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        border-radius: 50%;
        width: 18px;
        height: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
    }

    .notif-badge.d-none {
        display: none !important;
    }

    .notif-dropdown {
        display: none;
        position: absolute;
        right: 0;
        top: 48px;
        width: 320px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        z-index: 9999;
        overflow: hidden;
    }

    .notif-dropdown.show {
        display: block;
    }

    .notif-header {
        background: #1e2a3a;
        color: #fff;
        padding: 12px 16px;
        font-size: 14px;
        font-weight: 600;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .notif-header span.mark-read {
        font-size: 11px;
        font-weight: 400;
        cursor: pointer;
        color: #90caf9;
        text-decoration: underline;
    }

    .notif-tabs {
        display: flex;
        border-bottom: 1px solid #e0e0e0;
    }

    .notif-tab {
        flex: 1;
        text-align: center;
        padding: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        color: #666;
        border-bottom: 2px solid transparent;
        transition: all 0.2s;
    }

    .notif-tab.active {
        color: #1976d2;
        border-bottom: 2px solid #1976d2;
    }

    .notif-tab.full-width {
        width: 100%;
    }

    .notif-body {
        max-height: 280px;
        overflow-y: auto;
    }

    .notif-item {
        padding: 10px 14px;
        border-bottom: 1px solid #f0f0f0;
        font-size: 12px;
        line-height: 1.5;
    }

    .notif-item:last-child {
        border-bottom: none;
    }

    .notif-item .notif-title {
        font-weight: 600;
        color: #1a237e;
        margin-bottom: 2px;
    }

    .notif-item .notif-sub {
        color: #555;
    }

    .notif-item .notif-time {
        color: #aaa;
        font-size: 11px;
        margin-top: 2px;
    }

    .notif-empty {
        text-align: center;
        padding: 20px;
        color: #aaa;
        font-size: 12px;
    }

    .notif-footer {
        text-align: center;
        padding: 10px;
        border-top: 1px solid #f0f0f0;
    }

    .notif-footer a {
        font-size: 12px;
        color: #1976d2;
        text-decoration: none;
    }

    .tab-content-notif {
        display: none;
    }

    .tab-content-notif.active {
        display: block;
    }

    /* ===== BANNER KONTAK ===== */
    .banner-kontak {
        border-left: 5px solid #25d366;
        background: #f0fff4;
        border-radius: 6px;
        padding: 10px 16px;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
    }

    .banner-kontak .banner-icon {
        font-size: 26px;
    }

    .banner-kontak .banner-text h6 {
        margin: 0 0 2px;
        font-weight: 700;
        font-size: 13px;
        color: #1a3c2a;
    }

    .banner-kontak .banner-text p {
        margin: 0;
        font-size: 12px;
        color: #555;
    }

    .banner-kontak .banner-actions {
        margin-left: auto;
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }

    .banner-kontak .btn-wa {
        background: #25d366;
        color: #fff;
        border: none;
        border-radius: 20px;
        padding: 5px 14px;
        font-size: 12px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }

    .banner-kontak .btn-wa:hover {
        background: #1ebe5d;
        color: #fff;
    }

    .banner-kontak .btn-email {
        background: #fff;
        color: #555;
        border: 1px solid #ccc;
        border-radius: 20px;
        padding: 5px 14px;
        font-size: 12px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }

    .banner-kontak .btn-email:hover {
        background: #f5f5f5;
        color: #333;
    }

    /* ===== END BANNER KONTAK ===== */

    /* ===== HAMBURGER ANIMATION ===== */
    .hamburger-btn {
        background: none;
        border: none;
        cursor: pointer;
        padding: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        transition: background 0.2s;
    }

    .hamburger-btn:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .hamburger-box {
        width: 24px;
        height: 18px;
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .hamburger-line {
        display: block;
        width: 100%;
        height: 2px;
        background: #fff;
        border-radius: 2px;
        transition: all 0.35s cubic-bezier(0.645, 0.045, 0.355, 1.000);
        transform-origin: center;
    }

    /* Animasi saat aktif (sidebar mini) */
    .hamburger-btn.is-active .hamburger-line:nth-child(1) {
        transform: translateY(8px) rotate(45deg);
    }

    .hamburger-btn.is-active .hamburger-line:nth-child(2) {
        opacity: 0;
        transform: scaleX(0);
    }

    .hamburger-btn.is-active .hamburger-line:nth-child(3) {
        transform: translateY(-8px) rotate(-45deg);
    }

    /* ===== END HAMBURGER ANIMATION ===== */
    </style>
    <link href="{{ asset('css/admin-mobile.css') }}" rel="stylesheet">
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>

    <div id="main-wrapper">

        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <a class="navbar-brand" href="{{ route('backend.beranda') }}">
                        <b class="logo-icon p-l-10">
                            <img src="{{ asset('image/icon_univ_bsi.png') }}" alt="homepage" class="light-logo" />
                        </b>
                        <span class="logo-text">
                            <img src="{{ asset('image/logo_text.png') }}" alt="homepage" class="light-logo" />
                        </span>
                    </a>
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"
                        data-toggle="collapse" data-target="#navbarSupportedContent">
                        <i class="ti-more"></i>
                    </a>
                </div>

                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block">
                            {{-- Hamburger dengan animasi --}}
                            <a class="nav-link sidebartoggler waves-effect waves-dark" href="javascript:void(0)"
                                data-sidebartype="mini-sidebar" id="hamburgerToggle">
                                <button class="hamburger-btn" id="hamburgerBtn" tabindex="-1">
                                    <span class="hamburger-box">
                                        <span class="hamburger-line"></span>
                                        <span class="hamburger-line"></span>
                                        <span class="hamburger-line"></span>
                                    </span>
                                </button>
                            </a>
                        </li>
                    </ul>

                    <ul class="navbar-nav float-right">

                        {{-- ===== BELL NOTIFIKASI ===== --}}
                        @php
                        $isCustomer = auth()->user()->role === '2';
                        $tabLabel = $isCustomer ? 'Pesanan Anda' : 'Pesanan Baru';
                        @endphp

                        <li class="nav-item"
                            style="position: relative; margin-right: 10px; display:flex; align-items:center;">
                            <div class="notif-bell-wrapper" id="notifBellWrapper">
                                <a href="javascript:void(0)" id="notifBellBtn" class="nav-link waves-effect waves-dark"
                                    style="padding: 0 8px;">
                                    <i class="fas fa-bell font-20" style="color:#fff; font-size:20px;"></i>
                                    <span class="notif-badge d-none" id="notifCount">0</span>
                                </a>

                                <div class="notif-dropdown" id="notifDropdown">
                                    <div class="notif-header">
                                        <span id="notifHeaderText">Notifikasi (0)</span>
                                        <span class="mark-read" id="markAllRead">Tandai semua dibaca</span>
                                    </div>

                                    <div class="notif-tabs">
                                        <div class="notif-tab active {{ $isCustomer ? 'full-width' : '' }}"
                                            data-tab="pesanan">
                                            🛒 {{ $tabLabel }}
                                        </div>
                                        @if (!$isCustomer)
                                        <div class="notif-tab" data-tab="user">
                                            👤 User Baru
                                        </div>
                                        @endif
                                    </div>

                                    <div class="notif-body">
                                        <div class="tab-content-notif active" id="tab-pesanan">
                                            <div class="notif-empty">Memuat...</div>
                                        </div>
                                        @if (!$isCustomer)
                                        <div class="tab-content-notif" id="tab-user">
                                            <div class="notif-empty">Memuat...</div>
                                        </div>
                                        @endif
                                    </div>

                                    <div class="notif-footer">
                                        @if ($isCustomer)
                                        <a href="{{ url('/customer/riwayat-belanja') }}">
                                            🛍️ Pusat Riwayat Belanja
                                        </a>
                                        @else
                                        <a href="{{ route('backend.user.index') }}">👥 Lihat Semua User</a>
                                        &nbsp;&nbsp;|&nbsp;&nbsp;
                                        <a href="{{ route('admin.pesanan.index') }}">🛍️ Semua Pesanan</a>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </li>
                        {{-- ===== END BELL NOTIFIKASI ===== --}}

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href=""
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                @if (Auth::user()->foto && file_exists(public_path('storage/img-user/' .
                                Auth::user()->foto)))
                                <img src="{{ asset('storage/img-user/' . Auth::user()->foto) }}" alt="user"
                                    class="rounded-circle" width="31" height="31" style="object-fit: cover;">
                                @else
                                <i class="mdi mdi-account-circle font-24"></i>
                                @endif
                            </a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <div class="d-flex no-block align-items-center p-3 bg-dark text-white mb-2">
                                    <div>
                                        @if (Auth::user()->foto && file_exists(public_path('storage/img-user/' .
                                        Auth::user()->foto)))
                                        <img src="{{ asset('storage/img-user/' . Auth::user()->foto) }}" alt="user"
                                            class="rounded-circle" width="50" height="50" style="object-fit: cover;">
                                        @else
                                        <i class="mdi mdi-account-circle" style="font-size: 50px;"></i>
                                        @endif
                                    </div>
                                    <div class="ml-2">
                                        <h4 class="mb-0">{{ Auth::user()->nama }}</h4>
                                        <p class="mb-0">{{ Auth::user()->email }}</p>
                                    </div>
                                </div>
                                <a class="dropdown-item" href="{{ route('backend.profil.edit') }}">
                                    <i class="ti-user m-r-5 m-l-5"></i> Profil Saya
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href=""
                                    onclick="event.preventDefault(); document.getElementById('keluar-app').submit();">
                                    <i class="fa fa-power-off m-r-5 m-l-5"></i> Keluar
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">

                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="{{ route('backend.beranda') }}" aria-expanded="false">
                                <i class="mdi mdi-view-dashboard"></i>
                                <span class="hide-menu">Beranda</span>
                            </a>
                        </li>

                        @if (!$isCustomer)
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="{{ route('backend.user.index') }}" aria-expanded="false">
                                <i class="mdi mdi-account"></i>
                                <span class="hide-menu">User</span>
                            </a>
                        </li>
                        @endif

                        <li class="sidebar-item">
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                aria-expanded="false">
                                <i class="mdi mdi-shopping"></i>
                                <span class="hide-menu">Data Produk</span>
                            </a>
                            <ul aria-expanded="false" class="collapse first-level">
                                @if (!$isCustomer)
                                <li class="sidebar-item">
                                    <a href="{{ route('backend.kategori.index') }}" class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Kategori </span>
                                    </a>
                                </li>
                                @endif
                                <li class="sidebar-item">
                                    <a href="{{ $isCustomer ? route('customer.produk.index') : route('backend.produk.index') }}"
                                        class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Produk </span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        @if (!$isCustomer)
                        <li class="sidebar-item">
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                aria-expanded="false">
                                <i class="fas fa-file-alt"></i>
                                <span class="hide-menu">Data Laporan</span>
                            </a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item">
                                    <a href="{{ route('backend.laporan.formuser') }}" class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Laporan User </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="{{ route('backend.laporan.formproduk') }}" class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Laporan Produk </span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                aria-expanded="false">
                                <i class="fas fa-user-check"></i>
                                <span class="hide-menu">Approval</span>
                            </a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item">
                                    <a href="{{ route('backend.approval.lamaran.index') }}" class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Lamaran Kerja </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="{{ route('backend.approval.admin.index') }}" class="sidebar-link">
                                        <i class="mdi mdi-chevron-right"></i>
                                        <span class="hide-menu"> Akun Admin </span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark" href="{{ route('admin.pesanan.index') }}"
                                aria-expanded="false">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="hide-menu">Manajemen Transaksi</span>
                            </a>
                        </li>

                        {{-- ===== MENU LIVE CHAT (ADMIN) ===== --}}
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark" href="{{ route('backend.livechat') }}"
                                aria-expanded="false">
                                <i class="fas fa-comments"></i>
                                <span class="hide-menu">Live Chat</span>
                                <span id="sidebarChatBadge" class="badge badge-pill badge-danger ml-2"
                                    style="display:none;"></span>
                            </a>
                        </li>
                        {{-- ===== END MENU LIVE CHAT ===== --}}
                        @endif

                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href=""
                                onclick="event.preventDefault(); document.getElementById('keluar-app').submit();"
                                aria-expanded="false">
                                <i class="mdi mdi-power"></i>
                                <span class="hide-menu">Keluar</span>
                            </a>
                        </li>

                    </ul>
                </nav>
            </div>
        </aside>

        <div class="page-wrapper">
            <div class="container-fluid">

                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">@yield('judul')</h4>
                    </div>
                </div>

                @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                    <i class="fas fa-check-circle mr-2"></i>
                    {{ session('success') }}
                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
                @endif

                @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    {{ session('error') }}
                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
                @endif

                {{-- ===== BANNER KONTAK CUSTOMER ===== --}}
                @if ($isCustomer)
                <div class="banner-kontak">
                    <div class="banner-icon">🛎️</div>
                    <div class="banner-text">
                        <h6>Butuh Bantuan Seputar Pesanan?</h6>
                        <p>Tim kami siap membantu! Hubungi admin langsung via WhatsApp atau Email.</p>
                    </div>
                    <div class="banner-actions">
                        <a href="https://wa.me/6281299597075?text=Halo%20Admin%2C%20saya%20ingin%20menanyakan%20perihal%20pesanan%20saya."
                            target="_blank" class="btn-wa">
                            <i class="fab fa-whatsapp"></i> WhatsApp Admin
                        </a>
                        <a href="mailto:adety408@gmail.com?subject=Pertanyaan%20Pesanan%20Toko%20Online"
                            class="btn-email">
                            <i class="fas fa-envelope"></i> Email Admin
                        </a>
                    </div>
                </div>
                @endif
                {{-- ===== END BANNER KONTAK ===== --}}

                @yield('content')

            </div>

            <footer class="footer text-center">
                Web Programming. Studi Kasus Toko Online
                <a href="https://bsi.ac.id/">Kuliah..? BSI Aja !!!</a>
            </footer>
        </div>
    </div>

    <script src="{{ asset('backend/libs/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('backend/libs/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('backend/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('backend/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js') }}"></script>
    <script src="{{ asset('backend/extra-libs/sparkline/sparkline.js') }}"></script>
    <script src="{{ asset('backend/dist/js/waves.js') }}"></script>
    <script src="{{ asset('backend/dist/js/sidebarmenu.js') }}"></script>
    <script src="{{ asset('backend/dist/js/custom.min.js') }}"></script>
    <script src="{{ asset('backend/extra-libs/multicheck/datatable-checkbox-init.js') }}"></script>
    <script src="{{ asset('backend/extra-libs/multicheck/jquery.multicheck.js') }}"></script>
    <script src="{{ asset('backend/extra-libs/DataTables/datatables.min.js') }}"></script>

    <script>
    if ($('#zero_config').length) {
        $('#zero_config').DataTable();
    }

    function previewFoto() {
        const foto = document.querySelector('input[name="foto"]');
        const preview = document.querySelector('.foto-preview');
        const file = foto.files[0];
        const reader = new FileReader();
        reader.onloadend = function() {
            preview.src = reader.result;
        }
        if (file) {
            reader.readAsDataURL(file);
        }
    }

    function hanyaAngka(event) {
        return event.charCode >= 48 && event.charCode <= 57 || event.charCode == 46;
    }
    </script>

    <script src="{{ asset('ckeditor/ckeditor.js') }}"></script>
    <script>
    if (document.querySelector('#ckeditor')) {
        ClassicEditor
            .create(document.querySelector('#ckeditor'))
            .catch(error => {
                console.error(error);
            });
    }
    </script>

    <script>
    $(document).ready(function() {

        // ===== HAMBURGER ANIMATION =====
        $('#hamburgerToggle').on('click', function() {
            $('#hamburgerBtn').toggleClass('is-active');
        });
        // ===== END HAMBURGER ANIMATION =====

        // ===== NOTIFIKASI MUNCUL SAAT HOVER =====
        let notifHoverTimeout;
        $('#notifBellWrapper').on('mouseenter', function() {
            clearTimeout(notifHoverTimeout);
            $('#notifDropdown').addClass('show');
        }).on('mouseleave', function() {
            notifHoverTimeout = setTimeout(function() {
                $('#notifDropdown').removeClass('show');
            }, 200);
        });

        // Tetap bisa dibuka via klik (misalnya di layar sentuh)
        $('#notifBellBtn').on('click', function(e) {
            e.stopPropagation();
            $('#notifDropdown').toggleClass('show');

            // kalau masih ada angka di badge -> tandai sudah dibaca
            if (!$('#notifCount').hasClass('d-none')) {
                // angka langsung hilang (isi list tetap ditampilkan biar bisa dibaca)
                $('#notifCount').addClass('d-none').text('0');
                $('#notifHeaderText').text('Notifikasi (0)');

                // simpan ke server supaya nggak muncul lagi pas polling / refresh
                $.ajax({
                    url: '{{ route("backend.notifikasi.dibaca") }}',
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            }
        });

        $(document).on('click', function(e) {
            if (!$('#notifBellWrapper').is(e.target) && $('#notifBellWrapper').has(e.target).length ===
                0) {
                $('#notifDropdown').removeClass('show');
            }
        });
        // ===== END NOTIFIKASI HOVER =====

        // ===== DROPDOWN PROFIL MUNCUL SAAT HOVER =====
        let profileHoverTimeout;
        $('.nav-item.dropdown').on('mouseenter', function() {
            clearTimeout(profileHoverTimeout);
            $(this).addClass('show');
            $(this).find('.dropdown-menu').addClass('show');
        }).on('mouseleave', function() {
            const $this = $(this);
            profileHoverTimeout = setTimeout(function() {
                $this.removeClass('show');
                $this.find('.dropdown-menu').removeClass('show');
            }, 200);
        });
        // ===== END DROPDOWN PROFIL HOVER =====

        $('.notif-tab').on('click', function() {
            const tab = $(this).data('tab');
            $('.notif-tab').removeClass('active');
            $(this).addClass('active');
            $('.tab-content-notif').removeClass('active');
            $('#tab-' + tab).addClass('active');
        });

        $('#markAllRead').on('click', function() {
            $.ajax({
                url: '{{ route("backend.notifikasi.dibaca") }}',
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function() {
                    $('#notifCount').addClass('d-none').text('0');
                    $('#notifHeaderText').text('Notifikasi (0)');
                    $('#tab-pesanan').html(
                        '<div class="notif-empty">Tidak ada notifikasi baru</div>');
                    if ($('#tab-user').length) {
                        $('#tab-user').html(
                            '<div class="notif-empty">Tidak ada notifikasi baru</div>');
                    }
                }
            });
        });

        function fetchNotifikasi() {
            $.ajax({
                url: '{{ route("backend.notifikasi") }}',
                method: 'GET',
                success: function(data) {
                    const total = data.total_unread;
                    if (total > 0) {
                        $('#notifCount').removeClass('d-none').text(total > 99 ? '99+' : total);
                    } else {
                        $('#notifCount').addClass('d-none').text('0');
                    }
                    $('#notifHeaderText').text('Notifikasi (' + total + ')');

                    let htmlPesanan = '';
                    if (data.orders.length > 0) {
                        data.orders.forEach(function(o) {
                            let nomorPesanan = o.kode_pesanan || 'Baru';
                            let detailCustomer = (o.customer_name === 'Pesanan Anda') ? '' :
                                `<div class="notif-sub">Customer: ${o.customer_name}</div>`;
                            htmlPesanan += `
                                    <div class="notif-item">
                                        <div class="notif-title">🛒 ${o.customer_name === 'Pesanan Anda' ? 'Pesanan Anda' : 'Pesanan'} #${nomorPesanan}</div>
                                        ${detailCustomer}
                                        <div class="notif-sub">Total: ${o.total_format} &nbsp;|&nbsp;
                                            <span class="badge badge-warning">${o.status}</span>
                                        </div>
                                        <div class="notif-time">${o.waktu}</div>
                                    </div>`;
                        });
                    } else {
                        htmlPesanan =
                            '<div class="notif-empty">Tidak ada riwayat transaksi baru</div>';
                    }
                    $('#tab-pesanan').html(htmlPesanan);

                    if ($('#tab-user').length) {
                        let htmlUser = '';
                        if (data.users.length > 0) {
                            data.users.forEach(function(u) {
                                htmlUser += `
                                        <div class="notif-item">
                                            <div class="notif-title">👤 ${u.nama}</div>
                                            <div class="notif-sub">Email: ${u.email}</div>
                                            <div class="notif-sub">Role: <span class="badge badge-info">${u.role}</span></div>
                                            <div class="notif-time">${u.waktu}</div>
                                        </div>`;
                            });
                        } else {
                            htmlUser = '<div class="notif-empty">Tidak ada user baru</div>';
                        }
                        $('#tab-user').html(htmlUser);
                    }
                }
            });
        }

        fetchNotifikasi();
        setInterval(fetchNotifikasi, 15000);
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

    @if (!$isCustomer)
    {{-- ===== BADGE LIVE CHAT ADMIN (pesan belum dibaca) ===== --}}
    <script>
    (function() {
        const badge = document.getElementById('sidebarChatBadge');
        if (!badge) return;

        async function checkChatUnread() {
            try {
                const res = await fetch("{{ route('backend.livechat.conversations') }}", {
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                if (res.ok) {
                    const data = await res.json();
                    badge.style.display = data.total_unread > 0 ? 'inline-block' : 'none';
                    badge.textContent = data.total_unread > 9 ? '9+' : data.total_unread;
                }
            } catch (e) {}
        }

        checkChatUnread();
        setInterval(checkChatUnread, 10000);
    })();
    </script>
    {{-- ===== END BADGE LIVE CHAT ===== --}}
    @endif

    @stack('scripts')

    <form id="keluar-app" action="{{ route('backend.logout') }}" method="POST" class="d-none">
        @csrf
    </form>

</body>

</html>